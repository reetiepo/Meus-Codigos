package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.Scanner;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Separator;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class Main extends Application {

	// global variables
	private BorderPane borderPane;
	private TextArea textPad;
	// name of the file that will be saved and opened
	private String fileName = "mytext.txt";

	private Scene createScene() {
		borderPane = new BorderPane();

		// create the menus and give them an action
		Menu menuFile = new Menu("File");
		MenuItem menuOpenFile = new MenuItem("Open");
		menuOpenFile.setOnAction(e -> openFile());
		MenuItem menuSaveFile = new MenuItem("Save");
		menuSaveFile.setOnAction(e -> saveFile());
		menuFile.getItems().addAll(menuOpenFile, menuSaveFile);
		Menu menuEdit = new Menu("Edit");
		MenuItem menuClear = new MenuItem("Clear");
		menuClear.setOnAction(e -> actionClear());
		MenuItem menuSelectAll = new MenuItem("Select All");
		menuSelectAll.setOnAction(e -> actionSelectAll());
		MenuItem menuCut = new MenuItem("Cut");
		menuCut.setOnAction(e -> actionCut());
		MenuItem menuCopy = new MenuItem("Copy");
		menuCopy.setOnAction(e -> actionCopy());
		MenuItem menuPaste = new MenuItem("Paste");
		menuPaste.setOnAction(e -> actionPaste());
		menuEdit.getItems().addAll(menuSelectAll, menuCut, menuCopy, menuPaste);
		MenuBar menu = new MenuBar();
		menu.getMenus().addAll(menuFile, menuEdit);

		textPad = new TextArea();

		// create the buttons and give them an action
		Button btnOpen = new Button("Open");
		btnOpen.setOnAction(e -> openFile());
		Button btnSave = new Button("Save");
		btnSave.setOnAction(e -> saveFile());
		Button btnClear = new Button("Clear");
		btnClear.setOnAction(e -> actionClear());
		Button btnSelectAll = new Button("Select All");
		btnSelectAll.setOnAction(e -> actionSelectAll());
		Button btnCut = new Button("Cut");
		btnCut.setOnAction(e -> actionCut());
		Button btnCopy = new Button("Copy");
		btnCopy.setOnAction(e -> actionCopy());
		Button btnPaste = new Button("Paste");
		btnPaste.setOnAction(e -> actionPaste());
		CheckBox chbWrap = new CheckBox("Wrap text");
		chbWrap.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				textPad.setWrapText(chbWrap.isSelected());
			}
		});

		// create the toolbar and insert the buttons in it
		ToolBar toolBar = new ToolBar(new ToolBar(btnOpen, btnSave,
				new Separator(), btnClear, btnSelectAll, btnCut, btnCopy,
				btnPaste, new Separator(), chbWrap));

		// create the pane, with the menu on the top, the textpad in the center
		// and the toolbar in the bottom
		borderPane.setTop(menu);
		borderPane.setCenter(textPad);
		borderPane.setBottom(toolBar);
		return new Scene(borderPane, 470, 500);
	}

	// save the text file
	private void saveFile() {
		try {
			// create the file if it does not exist
			FileWriter file = new FileWriter(fileName);
			// copy the text from the textarea to the file
			file.write(textPad.getText());
			file.flush();
			file.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// open the file
	private void openFile() {
		String inputLine;
		
		try (Scanner inputFile = new Scanner(new File (fileName));){
			// clear the textarea
			textPad.clear();
			// verifies if there is a next line
			while (inputFile.hasNext()){
				// read the next line
				inputLine = inputFile.nextLine();
				// write the line in the textarea and add a new line
				textPad.appendText(inputLine + "\n");
			}
		}
		catch(FileNotFoundException fnf){
			System.out.println("File not found!");
		}
		catch(NoSuchElementException nsef){
			System.out.println("No line found!");
		}
	}

	// select all the text on the textarea
	private void actionSelectAll(){
		textPad.selectAll();
	}
	
	// cut the selected text
	private void actionCut(){
		textPad.cut();
	}
	
	// copy the selected text
	private void actionCopy(){
		textPad.copy();
	}
	
	// paste 
	private void actionPaste(){
		textPad.paste();
	}
	
	// clear and give focus to the textarea
	private void actionClear(){
		textPad.clear();
		textPad.requestFocus();
	}

	@Override
	public void start(Stage stage) throws Exception {
		stage.setScene(createScene());
		stage.show();
	}

	public static void main(String[] args) {
		Application.launch(args);
	}
}
