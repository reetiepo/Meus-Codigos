package application;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;


public class Main extends Application {
	
	public Text qtdMoves;
	
	public int moves;
	
	public static int size = 4;
	
	public GridPane gridPane;
	
	public BorderPane borderPane;
	
	public List<Integer> numbers;
	
	public List<Integer> finalNumbers;
	
	@Override
	public void start(Stage primaryStage) {
		try {
			borderPane = new BorderPane();
			
			gridPane = new GridPane();
			
			gridPane.setGridLinesVisible(true);
			
			numbers = new ArrayList<Integer>();
			finalNumbers = new ArrayList<Integer>();
			 
			for (int j = 1; j < (size*size); j++){
				numbers.add(j);
				finalNumbers.add(j);
			}
			numbers.add(0);
			finalNumbers.add(0);
			 
			Collections.shuffle(numbers);
			qtdMoves = new Text("Moves: 0");

			updatePanes();

			Scene scene =  new Scene(borderPane,361,390);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setTitle("Slide");
			primaryStage.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	public void slide(int number, int row, int col) {		
		int count = 0;
		for (int i = 0; i < size; i++){
			for (int j = 0; j < size; j++){
				if (numbers.get(count) == 0){
					if ((i == row && (j == (col+1) || j == (col-1))) || 
					(j == col && (i == (row+1) || i == (row-1)))) {
						move(number);
						i = j = size; //break
					}
				}
				count++;
			}
		}
	}
	
	public void move(int number){
		for (int j = 0; j < (size*size); j++){
			if (numbers.get(j) == 0)
				numbers.set(j, number);
			else if (numbers.get(j) == number)
				numbers.set(j, 0);
		}
		moves++;
		
		if (verify()){
			qtdMoves = new Text("YOU WON with " + moves + " moves!");
			qtdMoves.setFill(Color.RED);
			updatePanes();
			gridPane.setDisable(true);
		}
		else{
			qtdMoves = new Text("Moves: " + moves);
			updatePanes();
		}
	}
	
	public boolean verify(){
		for (int j = 0; j < (size*size); j++){
			if (numbers.get(j) != finalNumbers.get(j))
				return false;
		}
		return true;
	}
	
	public void updatePanes(){
		gridPane.getChildren().clear();
		Button btnTmpNum;
		int count = 0;
		for (int i = 0; i < size; i++){
			for (int j = 0; j < size; j++){
				int num = numbers.get(count);
				if (num == 0)
					btnTmpNum = new Button("");
				else
					btnTmpNum = new Button("" + num + "");
				
				int row = i;
				int col = j;
				btnTmpNum.setOnMouseClicked(e -> slide(num, row, col));
				btnTmpNum.setTextFill(Color.YELLOW);
				btnTmpNum.setMinSize(90, 90);
				btnTmpNum.setMaxSize(90, 90);
				btnTmpNum.setStyle("-fx-font-size: 30px; -fx-border: 1px solid; "
						+ "-fx-border-color: yellow; -fx-background-color: red;");
				
				GridPane.setConstraints(btnTmpNum, j, i);
				GridPane.setHalignment(btnTmpNum, HPos.CENTER);
				GridPane.setValignment(btnTmpNum, VPos.CENTER);
				gridPane.getChildren().add(btnTmpNum);
				count++;
			}
		}
		borderPane.setCenter(gridPane);
		borderPane.setBottom(qtdMoves);
	}
}
