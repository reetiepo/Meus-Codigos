package application;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			GridPane gridPane = new GridPane();
			
			gridPane.setGridLinesVisible(false);
			gridPane.setVgap(10);
			gridPane.setHgap(10);
			Text txtTmpNum = new Text("0");

			for (int i = 0; i < 10; i++){
				for (int j = 0; j < 10; j++){
					if (i == 0){
						txtTmpNum = new Text("" + j + "");
					}
					else if (j == 0){
						txtTmpNum = new Text("" + i + "");
					}
					else {
						txtTmpNum = new Text("" + (i * j) + "");
					}
					
					GridPane.setConstraints(txtTmpNum, i, j);
					GridPane.setHalignment(txtTmpNum, HPos.CENTER);
					GridPane.setValignment(txtTmpNum, VPos.CENTER);
					GridPane.setMargin(txtTmpNum, new Insets(5, 10, 5, 10));
					gridPane.getChildren().add(txtTmpNum);
				}
			}
			
			
			Scene scene = new Scene(gridPane,405,350);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setTitle("Multiplication Table");
			primaryStage.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
