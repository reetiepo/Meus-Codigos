package application;
	
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;


public class Main extends Application {
	
	private Button btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, buttonPlus, buttonMinus, buttonDivide, buttonMultiply, buttonCompute;
	private Label answerDisplay;
	private BorderPane borderPane;
	private GridPane buttonPane;
	private double num1, num2;
	private String operatorText;
	
	private Scene buildScene(){
		borderPane = new BorderPane();
		borderPane.setPadding(new Insets(10, 10, 10, 10));
		borderPane.setMinSize(200, 200);
		
		buttonPane = new GridPane();

		btn0 = new Button("0");
		btn0.setMinWidth(30);
		btn0.setMinHeight(30);
		btn1 = new Button("1");
		btn1.setMinWidth(30);
		btn1.setMinHeight(30);
		btn2 = new Button("2");
		btn2.setMinWidth(30);
		btn2.setMinHeight(30);
		btn3 = new Button("3");
		btn3.setMinWidth(30);
		btn3.setMinHeight(30);
		btn4 = new Button("4");
		btn4.setMinWidth(30);
		btn4.setMinHeight(30);
		btn5 = new Button("5");
		btn5.setMinWidth(30);
		btn5.setMinHeight(30);
		btn6 = new Button("6");
		btn6.setMinWidth(30);
		btn6.setMinHeight(30);
		btn7 = new Button("7");
		btn7.setMinWidth(30);
		btn7.setMinHeight(30);
		btn8 = new Button("8");
		btn8.setMinWidth(30);
		btn8.setMinHeight(30);
		btn9 = new Button("9");
		btn9.setMinWidth(30);
		btn9.setMinHeight(30);

		buttonPlus = new Button("+");
		buttonPlus.setMinWidth(30);
		buttonPlus.setMinHeight(30);
		buttonMinus = new Button("-");
		buttonMinus.setMinWidth(30);
		buttonMinus.setMinHeight(30);
		buttonDivide = new Button("/");
		buttonDivide.setMinWidth(30);
		buttonDivide.setMinHeight(30);
		buttonMultiply = new Button("*");
		buttonMultiply.setMinWidth(30);
		buttonMultiply.setMinHeight(30);
		buttonCompute = new Button("=");
		buttonCompute.setMinWidth(30);
		buttonCompute.setMinHeight(30);
		
		setActionHandlers();
		
		answerDisplay = new Label();
		answerDisplay.setPadding(new Insets(0, 5, 0, 0));
		answerDisplay.setAlignment(Pos.CENTER_RIGHT);
		answerDisplay.setMinHeight(20);
		answerDisplay.setMinWidth(180);
		answerDisplay.setStyle("fx-font-size: 12pt; -fx-font-family: 'Tahoma'; -fx-background-color: white; -fx-border: .5px solid; -fx-border-color: black; "
				+ "-fx-background-radius: 5.0; -fx-border-radius: 5.0");
		
		borderPane.setTop(answerDisplay);

		buttonPane.setAlignment(Pos.CENTER);
		buttonPane.add(buttonDivide, 0, 1);
		buttonPane.add(buttonMultiply, 1, 1);
		buttonPane.add(buttonMinus, 2, 1);
		buttonPane.add(buttonPlus, 3, 1);
		buttonPane.add(btn7, 0, 2);
		buttonPane.add(btn8, 1, 2);
		buttonPane.add(btn9, 2, 2);
		buttonPane.add(btn4, 0, 3);
		buttonPane.add(btn5, 1, 3);
		buttonPane.add(btn6, 2, 3);
		buttonPane.add(btn1, 0, 4);
		buttonPane.add(btn2, 1, 4);
		buttonPane.add(btn3, 2, 4);
		buttonPane.add(btn0, 0, 5);
		buttonPane.add(buttonCompute, 2, 5);
		buttonPane.setVgap(10);
		buttonPane.setHgap(10);
		
		borderPane.setCenter(buttonPane);
		
		return new Scene(borderPane);
	}
	
	private void processNumber(String number){
		answerDisplay.setText(answerDisplay.getText() + number);
	}
	
	private void processOperator(String operator){
		operatorText = operator;
		num1 = Double.parseDouble(answerDisplay.getText());
		answerDisplay.setText("");
	}
	
	private void compute(){
		num2 = Double.parseDouble(answerDisplay.getText());
		double total = 0;
		
		switch(operatorText){
			case "+":
				total = num1 + num2;
				break;
			case "-":
				total = num1 - num2;
				break;
			case "/":
				total = num1 / num2;
				break;
			case "*":
				total = num1 * num2;
				break;
		}
		
		answerDisplay.setText(Double.toString(total));
	}
	
	private void setActionHandlers(){
		btn0.setOnAction(e -> processNumber(btn0.getText()));
		btn1.setOnAction(e -> processNumber(btn1.getText()));
		btn2.setOnAction(e -> processNumber(btn2.getText()));
		btn3.setOnAction(e -> processNumber(btn3.getText()));
		btn4.setOnAction(e -> processNumber(btn4.getText()));
		btn5.setOnAction(e -> processNumber(btn5.getText()));
		btn6.setOnAction(e -> processNumber(btn6.getText()));
		btn7.setOnAction(e -> processNumber(btn7.getText()));
		btn8.setOnAction(e -> processNumber(btn8.getText()));
		btn9.setOnAction(e -> processNumber(btn9.getText()));
		buttonPlus.setOnAction(e -> processOperator("+"));
		buttonMinus.setOnAction(e -> processOperator("-"));
		buttonDivide.setOnAction(e -> processOperator("/"));
		buttonMultiply.setOnAction(e -> processOperator("*"));
		buttonCompute.setOnAction(e -> compute());
	}
	
	@Override
	public void start(Stage stage) throws Exception {
		stage.setScene(buildScene());
		stage.show();			
	}
	
	public static void main(String[] args) {
		Application.launch(args);
	}
}
