
public abstract class Shape {

	public Shape(){
		
	}
	
	protected abstract double getPerimeter();
	
	protected abstract double getArea();
	
	public static void printInfo(){
		System.out.println("This is a generic shape.");
	}
}
