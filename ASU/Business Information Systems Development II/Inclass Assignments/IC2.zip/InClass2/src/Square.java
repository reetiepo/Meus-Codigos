
public class Square extends Shape {

	private int side;
	
	public int getSide() {
		return side;
	}
	
	public void setSide(int side) {
		this.side = side;
	}
	
	public Square(){
		
	}

	public Square(int s){
		setSide(s);
	}
	
	@Override
	protected double getPerimeter() {
		return getSide() * 4;
	}

	@Override
	protected double getArea() {
		return getSide() * getSide();
	}
	
	@Override
	public String toString(){
		return "Square with side " + getSide();
	}

}
