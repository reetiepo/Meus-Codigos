import java.util.Scanner;

public class ShapeManager {
	
	private static Shape[] shapeParts;
	
	public static void main(String[] args) {
		createShape();
	}

	private static void createShape(){
		System.out.println("Do you want a Big (S)quare or a Big (T)riangle? ");
		Scanner s = new Scanner(System.in);
		String ans = s.nextLine();
		
		if (ans.equalsIgnoreCase("S") || ans.equalsIgnoreCase("T")){
			//SQUARE
			if (ans.equalsIgnoreCase("S")){
				System.out.print("Enter Square side: ");
				int squareSide = s.nextInt();
				shapeParts = new Shape[4];
				for (int i = 0; i < shapeParts.length; i++){
					shapeParts[i] = new Square(squareSide);
				}
			}
			//TRIANGLE
			else if (ans.equalsIgnoreCase("T")){
				System.out.print("Enter Triangle base: ");
				int triangleBase = s.nextInt();
				System.out.print("Enter Triangle height: ");
				int triangleHeight = s.nextInt();
				shapeParts = new Shape[2];
				for (int i = 0; i < shapeParts.length; i++){
					shapeParts[i] = new Triangle();;
					Triangle tmpTriangle = (Triangle)shapeParts[i];
					tmpTriangle.setBase(triangleBase);
					tmpTriangle.setHeight(triangleHeight);
				}
			}
			
			printShapeComponents();
			System.out.printf("The area of the shape is: %1$.2f\n", getArea());
			System.out.printf("The perimeter of the shape is: %1$.2f", getPerimeter());
			s.close();
		}
	}
	
	private static double getArea(){
		double count = 0;
		for (int i = 0; i < shapeParts.length; i++){
			count += shapeParts[i].getArea();
		}
		return count;
		
	}
	
	private static double getPerimeter(){
		double count = 0;
		for (int i = 0; i < shapeParts.length; i++){
			count += shapeParts[i].getPerimeter();
		}
		return count;
	}
	
	private static void printShapeComponents(){
		for (int i = 0; i < shapeParts.length; i++){
			System.out.println(shapeParts[i].toString());
		}
	}
}
