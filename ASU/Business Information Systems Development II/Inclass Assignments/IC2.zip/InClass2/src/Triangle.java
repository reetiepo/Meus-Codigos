
public class Triangle extends Shape {

	private int base;
	private int height;
	
	public int getBase() {
		return base;
	}
	
	public void setBase(int base) {
		this.base = base;
	}
	
	public int getHeight() {
		return height;
	}
	
	public void setHeight(int height) {
		this.height = height;
	}
	
	public Triangle(){
		
	}

	public Triangle(int b, int h){
		setBase(b);
		setHeight(h);
	}
	
	@Override
	protected double getPerimeter() {
		return getBase() + getHeight() + Math.sqrt(Math.pow(getBase(),2) + Math.pow(getHeight(),2));
	}

	@Override
	protected double getArea() {
		return getBase() * getHeight() / 2;
	}
	
	@Override
	public String toString(){
		return "Triangle with base " + getBase() + " and height " + getHeight();
	}

}
