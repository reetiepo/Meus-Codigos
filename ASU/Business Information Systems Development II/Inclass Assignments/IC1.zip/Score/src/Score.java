
public class Score {

	private int score;
	
	private int totalOutOfPoints;
	
	public Score(){
		score = 0;
		totalOutOfPoints = 100;
	}
	
	public void setScore(int value){
		score = value;
	}
	
	public int getScore(){
		return score;
	}
	
	public void setTotalOutOfPoints(int value){
		totalOutOfPoints = value;
	}
	
	public int getTotalOutOfPoints(){
		return totalOutOfPoints;
	}
}
