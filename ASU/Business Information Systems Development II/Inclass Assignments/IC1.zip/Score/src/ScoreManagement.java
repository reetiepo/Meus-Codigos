import java.util.Scanner;

public class ScoreManagement {

	private Score[] scoreArray;
	private static boolean arrayNull = false;

	public static void main(String[] args) {
		ScoreManagement sm = new ScoreManagement();
		sm.readScores();
		sm.calculateAverage();
		sm.calculateHighest();

		if (arrayNull) {
			System.out.println("There were no scores.");
		}
	}

	public ScoreManagement() {
		scoreArray = new Score[10];
	}

	public void readScores() {
		Scanner s = new Scanner(System.in);
		int score;

		System.out
				.println("In the following lines, enter the scores one line at time.");
		System.out
				.println("When you are done enter -1 to indicate that all scores have been entered.");

		for (int i = 0; i < 10; i++) {
			System.out.print("Enter score " + (i + 1) + ": ");
			score = Integer.parseInt(s.nextLine());
			scoreArray[i] = new Score();
			scoreArray[i].setScore(score);
			if (score == -1) {
				i = 10;
			}
		}
		System.out.println("Input Complete.");
		s.close();
	}

	public void calculateAverage() {
		float average = 0;

		if (scoreArray[0] == null) {
			arrayNull = true;
		} else {
			for (int i = 0; i < 10; i++) {
				if (scoreArray[i].getScore() != -1) {
					average += scoreArray[i].getScore();
				} else {
					average /= i;
					i = 10;
				}
			}
			System.out.printf("The average is %1$.2f\n", average);
		}
	}

	public void calculateHighest() {
		int highest = -1;

		if (scoreArray[0] == null) {
			arrayNull = true;
		} else {
			for (int i = 0; i < 10; i++) {
				if (scoreArray[i].getScore() != -1) {
					if (scoreArray[i].getScore() > highest) {
						highest = scoreArray[i].getScore();
					}
				} else {
					i = 10;
				}
			}
			System.out.print("The highest score was " + highest);
		}
	}
}
