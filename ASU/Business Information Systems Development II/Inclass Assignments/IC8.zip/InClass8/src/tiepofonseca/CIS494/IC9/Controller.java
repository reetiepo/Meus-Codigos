package tiepofonseca.CIS494.IC9;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Controller {

	@FXML
	private Button okButton;
	@FXML
	private TextField num1, num2;
	@FXML
	private Label result;
	
	@FXML 
	private void okButtonHandler(ActionEvent e){
		System.out.println("Button action event!");
		
		int r = Integer.parseInt(num1.getText()) + Integer.parseInt(num2.getText());
		
		result.setText(String.valueOf(r));
		
		System.out.println("The total is " + r);
	}
	
	@FXML 
	private void initialize(){
		System.out.println("Initializing!");
	}
}
