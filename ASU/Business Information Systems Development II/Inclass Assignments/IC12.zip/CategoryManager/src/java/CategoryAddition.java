/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.sql.*;

/**
 *
 * @author reetiepo
 */
@Named(value = "categoryAdditionBean")
@SessionScoped
public class CategoryAddition implements Serializable {

    /**
     * Creates a new instance of CategoryAddition
     */
    public CategoryAddition() {
        initializeJDBC();
    }
    
    private PreparedStatement statement;
    
    private String updateStatus;
    
    private String categoryName;

    /**
     * @return the updateStatus
     */
    public String getUpdateStatus() {
        return updateStatus;
    }

    /**
     * @param updateStatus the updateStatus to set
     */
    public void setUpdateStatus(String updateStatus) {
        this.updateStatus = updateStatus;
    }

    /**
     * @return the categoryName
     */
    public String getCategoryName() {
        return categoryName;
    }

    /**
     * @param categoryName the categoryName to set
     */
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
    
    public void initializeJDBC() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/sakila", "user1", "1234");
            String query = "INSERT INTO category(name) VALUES (?);";
            statement = connection.prepareStatement(query);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public boolean isRequiredFieldFilled() {
        return getCategoryName() != null;
    }
    
    public String processSubmit() {
        if (isRequiredFieldFilled())
                return "ConfirmCategory";
        return "";
    }
    
    public String getRequiredFields() {
        if (isRequiredFieldFilled())
                return "";
        return "Category name is required.";
    }
    
    public String getInput() {
        return "<p style='color:red'> You entered <br/>" +
               "Category Name: " + getCategoryName() + "</p>";
    }
    
    public String storeCategory() {
        try {
            statement.setString(1, getCategoryName());
            statement.executeUpdate();
            
            setUpdateStatus(getCategoryName() + " inserted with sucess!");
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        
        return "CategoryStored";
    }
}
