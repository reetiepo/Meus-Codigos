
public class StudentRoster {

	private Student roster[];
	private int studentCount;
	
	public StudentRoster() {
		// TODO Auto-generated constructor stub
		
		roster = new Student[10];
		studentCount = 0;

	}
	
	public void AddStudent(Student value){
		
		// Take the provided student and add it to the array
		// at the location specified by the counter.
		// Increment the counter after doing so
		
		roster[studentCount++] = value;
		
	}
	
	public void printStudentList(){
		
		System.out.println("The following are students in the Roster");
		
		for(int i = 0; i < studentCount; i++){
			
			System.out.printf("First name: %1$s\t", roster[i].getFirstName());
			
			if (roster[i] instanceof GraduateStudent){
				GraduateStudent tmpGradStudent = (GraduateStudent)roster[i];
				System.out.printf("Thesis title: %1$s", tmpGradStudent.getMasterThesis());
			}
			else if (roster[i] instanceof PhDStudent){
				PhDStudent tmpPhDStudent = (PhDStudent)roster[i];
				System.out.printf("Dissertation title: %1$s", tmpPhDStudent.getDissertation());
			}
			
			System.out.println();
			
		} // end for
	
	} // end method
	
}
