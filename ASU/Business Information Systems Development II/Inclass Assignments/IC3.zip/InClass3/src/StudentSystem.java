import java.util.Scanner;

public class StudentSystem {

	private StudentRoster theRoster = new StudentRoster();
	
	public static void main (String[] args){
		
		// Create an instance of StudentSystem and call the processStudents method.
		
		StudentSystem myStudentSystem = new StudentSystem();
		myStudentSystem.processStudents();
		
	}
	
	
	private void processStudents(){
			
		// stores what the user wants to do
		String userInput = "";
		
		
		// temporary variables for student instances
		String firstName;
		String lastName;
		
		System.out.println("\t\tStudentManagementSystem");
		Scanner s = new Scanner(System.in);
		
		System.out.println("Press X to exit.");
		
		do {
			
			System.out.print("Do you want a (S)tudent, (G)radStudent or (P)hD Student? ");
			
			// store user input in uppercase.
			userInput = s.nextLine();
			userInput = userInput.toUpperCase();
			
			// We need this to avoid one extra prompt after user selects X
			if(userInput.equals("X"))
				break;
			
			System.out.print("Enter first name: ");
			firstName = s.nextLine();
			System.out.print("Enter last name: ");
			lastName = s.nextLine();
			
			switch(userInput){
			case "G":	
				String thesis;
				System.out.print("Enter thesis title: ");
				thesis = s.nextLine();
				GraduateStudent gradStudent = new GraduateStudent();
				gradStudent.setMasterThesis(thesis);
				gradStudent.setFirstName(firstName);
				gradStudent.setLastName(lastName);
				theRoster.AddStudent(gradStudent);
				break;
			case "P":	
				String dissertation;
				System.out.print("Enter dissertation title: ");
				dissertation = s.nextLine();
				PhDStudent phdStudent = new PhDStudent();
				phdStudent.setDissertation(dissertation);
				phdStudent.setFirstName(firstName);
				phdStudent.setLastName(lastName);
				theRoster.AddStudent(phdStudent);
				break;
			default:	
				Student student = new Student();
				student.setFirstName(firstName);
				student.setLastName(lastName);
				theRoster.AddStudent(student);
				break;
			}
		
		// Keep on looping while input is not X
		} while (! userInput.equalsIgnoreCase("X"));
		
		// INSERT CALL to printStudentList method of theRoster
		theRoster.printStudentList();
		
		// close Scanner so there is no memory/resource leak.
		s.close();
		
	}

}
