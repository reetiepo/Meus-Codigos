
public class PhDStudent extends Student {
	
	private String dissertation;

	public String getDissertation() {
		return dissertation;
	}

	public void setDissertation(String dissertation) {
		this.dissertation = dissertation;
	}
	
}
