
public class GraduateStudent extends Student {
	
	private String masterThesis;

	public String getMasterThesis() {
		return masterThesis;
	}

	public void setMasterThesis(String masterThesis) {
		this.masterThesis = masterThesis;
	}
	
}
