
public class Student {

	private String firstName;
	private String lastName;
	private int ID;
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public Student() {
		// TODO Auto-generated constructor stub
		firstName = "";
		lastName = "";
		ID = 0;
	}
		
	public Student(String firstName, String lastName, int iD) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		ID = iD;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}



}
