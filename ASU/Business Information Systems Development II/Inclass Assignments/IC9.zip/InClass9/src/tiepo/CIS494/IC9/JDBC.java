package tiepo.CIS494.IC9;

import java.util.Scanner;
import java.sql.*;

public class JDBC {
	
	public static void main(String[] args) {
		//connectToDatabase();
		usePreparedStatement();
	}

	private static void connectToDatabase() {
		String query = "";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded.");
			
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/sakila", "user1", "1234");
			System.out.println("Database Connected.");
			Statement statement = connection.createStatement();
			query = "SELECT title, release_year FROM film;";
			ResultSet resultSet = statement.executeQuery(query);
			
			while (resultSet.next()){
				System.out.println(resultSet.getString(1) + " " + resultSet.getString(2));
			}
		}
		catch (ClassNotFoundException ex){
			System.out.print("Class not found!");
		}
		catch (SQLException ex){
			System.out.print(ex.getMessage());
		}		
	}

	private static void usePreparedStatement() {
		PreparedStatement preparedStatement;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded.");
			
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/sakila", "user1", "1234");
			System.out.println("Database Connected.");
			String query = "SELECT first_name, last_name FROM customer WHERE first_name = ?;";
			preparedStatement = connection.prepareStatement(query);
			System.out.println("Enter name for customer you want to search for:");
			Scanner s = new Scanner(System.in);
			preparedStatement.setString(1, s.nextLine());
			ResultSet resultSet = preparedStatement.executeQuery();
			
			while (resultSet.next()){
				System.out.println(resultSet.getString(1) + " " + resultSet.getString(2));
			}
			
			s.close();
		}
		catch (ClassNotFoundException ex){
			ex.printStackTrace();
		}
		catch (SQLException ex){
			ex.printStackTrace();
		}
	}
}
