package application;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;


public class Main extends Application {
	
	private Rectangle blueBox, redBox, yellowBox, greenBox, blackBox;
	private BorderPane borderPane;
	private VBox colorPane;
	private Pane drawingPane;
	private Circle dot;
	private Scene scene;
	
	private double xLocation, yLocation;
	private double xShift, yShift;
	private String currentColor;
	
	private Paint getPaintValue(){
		return Paint.valueOf(currentColor);
	}
	
	private void initializeDrawingOptions(){
		xShift = 2;
		yShift = 2;
		
		xLocation = 50;
		yLocation = 50;
		
		currentColor = "Black";
		
		dot = new Circle(xLocation, yLocation, 2, getPaintValue());
		
		drawingPane.getChildren().add(dot);
	}
	
	private void drawingPaneKeyPressedEvent(KeyEvent e){
		switch(e.getCode()){
		case UP:
			yLocation -= yShift;
			break;
		case DOWN:
			yLocation += yShift;
			break;
		case LEFT:
			xLocation -= xShift;
			break;
		case RIGHT:
			xLocation += xShift;
			break;
		}
		
		dot = new Circle(xLocation, yLocation, 2, getPaintValue());
		
		drawingPane.getChildren().add(dot);
	}
	
	private void createScene(){
		borderPane = new BorderPane();
		drawingPane = new Pane();
		drawingPane.setOnKeyPressed(e -> drawingPaneKeyPressedEvent(e));
		colorPane = new VBox();
		initializeDrawingOptions();

		blueBox = new Rectangle(20, 20, Color.BLUE);
		blueBox.setOnMouseClicked(e -> mouseClickedBox("Blue", blueBox));
		redBox = new Rectangle(20, 20, Color.RED);
		redBox.setOnMouseClicked(e -> mouseClickedBox("Red", redBox));
		yellowBox = new Rectangle(20, 20, Color.YELLOW);
		yellowBox.setOnMouseClicked(e -> mouseClickedBox("Yellow", yellowBox));
		greenBox = new Rectangle(20, 20, Color.GREEN);
		greenBox.setOnMouseClicked(e -> mouseClickedBox("Green", greenBox));
		blackBox = new Rectangle(20, 20, Color.BLACK);
		blackBox.setOnMouseClicked(e -> mouseClickedBox("Black", blackBox));
	
		colorPane.getChildren().addAll(blueBox, redBox, yellowBox, greenBox, blackBox);
		borderPane.setLeft(colorPane);
		borderPane.setCenter(drawingPane);
		scene = new Scene(borderPane, 300, 300);
		drawingPane.requestFocus();
	}
	
	private void mouseClickedBox(String color, Rectangle box){
		currentColor = color;

		blueBox.setStroke(null);
		redBox.setStroke(null);
		yellowBox.setStroke(null);
		greenBox.setStroke(null);
		blackBox.setStroke(null);
		
		box.setStroke(Color.BLACK);
		
		drawingPane.requestFocus();
	}
	
	@Override
	public void start(Stage stage) throws Exception {
		createScene();
		stage.setScene(scene);
		stage.show();			
	}
	
	public static void main(String[] args) {
		Application.launch(args);
	}
}
