package tiepo.CIS494.IC10;

import java.util.ArrayList;

public class ActorList {

	private ArrayList<Actor> listOfActors;
	
	public ActorList(){
		listOfActors = new ArrayList<Actor>();
	}

	public ArrayList<Actor> getListOfActors() {
		return listOfActors;
	}

	public void setListOfActors(ArrayList<Actor> listOfActors) {
		this.listOfActors = listOfActors;
	}
}
