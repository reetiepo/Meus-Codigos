package tiepo.CIS494.IC10;

public class Controller {

	ActorView view;
	ActorList model;
	
	public Controller(ActorView actorView, ActorList actorList){
		view = actorView;
		model = actorList;
	}
	
	public void updateView(){
		view.printActors(model);
	}
}
