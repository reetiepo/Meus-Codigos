package tiepo.CIS494.IC10;

public class ActorView {

	public void printActors(ActorList actorList){
		for (Actor a : actorList.getListOfActors()){
			System.out.println(a.getFirstName() + " " + a.getLastName());
		}
	}
}
