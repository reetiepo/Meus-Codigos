package tiepo.CIS494.IC10;

import java.util.ArrayList;
import java.sql.*;

public class MVCDBProject {
	
	public static void main(String[] args) {
		actorList = new ActorList();
		getActorListFromDB();
		ActorView view = new ActorView();
		Controller controller = new Controller(view, actorList);
		controller.updateView();
	}

	private static ActorList actorList;
	
	private static void getActorListFromDB() {
		String query = "";
		ArrayList<Actor> list = new ArrayList<Actor>();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded.");
			
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/sakila", "user1", "1234");
			System.out.println("Database Connected.");
			Statement statement = connection.createStatement();
			query = "SELECT first_name, last_name FROM actor;";
			ResultSet resultSet = statement.executeQuery(query);
			
			while (resultSet.next()){
				list.add(new Actor(resultSet.getString(1), resultSet.getString(2)));
			}
			
			actorList.setListOfActors(list);
		}
		catch (ClassNotFoundException ex){
			System.out.print("Class not found!");
		}
		catch (SQLException ex){
			System.out.print(ex.getMessage());
		}		
	}
}
