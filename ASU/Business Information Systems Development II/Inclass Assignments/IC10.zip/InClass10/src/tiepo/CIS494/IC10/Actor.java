package tiepo.CIS494.IC10;

public class Actor {

	private String firstName;
	
	private String lastName;
	
	public Actor(String first_name, String last_name) {
		setFirstName(first_name);
		setLastName(last_name);
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
}
