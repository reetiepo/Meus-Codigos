/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.inject.Named;
import javax.enterprise.context.ApplicationScoped;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author reetiepo
 */
@Named(value = "categoryBean")
@ApplicationScoped
public class CategoryJSFBean {

    /**
     * Creates a new instance of CategoryJSFBean
     */
    public CategoryJSFBean() {
        loadCategories();
    }
    
    private PreparedStatement categoryStatement;
    
    private String choice;
    
    private String[] categories;
    
    public String getChoice() {
        return choice;
    }
    
    public void setChoice(String c) {
        choice = c;
    }
    
    public String[] getCategories() {
        return categories;
    }
    
    public void setCategories(String[] c) {
        categories = c;
    }
    
    public ResultSet getFilms() throws SQLException {
        if (choice == null) {
            if (categories.length == 0){
                return null;
            }
            else {
                categoryStatement.setString(1, categories[0]);
            }
        }
        else {
            categoryStatement.setString(1, choice);
        }
        
        return categoryStatement.executeQuery();
    }
    
    private void loadCategories() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/sakila", "user1", "1234");
            String query = "SELECT name FROM category;";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            ArrayList<String> list = new ArrayList<>();

            while (resultSet.next()){
                    list.add(resultSet.getString(1));
            }

            categories = new String[list.size()];
            list.toArray(categories);

            query = "SELECT f.title, f.description, f.release_year FROM film f " +
                    "INNER JOIN film_category fc ON fc.film_id = f.film_id " +
                    "INNER JOIN category c ON c.category_id = fc.category_id " +
                    "WHERE c.name = ?";  
            categoryStatement = connection.prepareStatement(query);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
