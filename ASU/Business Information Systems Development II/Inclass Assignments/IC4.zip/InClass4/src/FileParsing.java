import java.util.Scanner;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.io.*;
import java.math.BigDecimal;

public class FileParsing {

	static ArrayList<Transaction> transactionList = new ArrayList<Transaction>();
	
	public FileParsing() {
		// TODO Auto-generated constructor stub
	}
	
	private static void processLine(String line){
		String[] splitLine = line.split(",");
		
		String entity, payee, date, amountString;
		double amount;
		Transaction temp;

		entity = splitLine[0].replaceAll("\"", "");
		payee = splitLine[1].replaceAll("\"", "");
		date = splitLine[2].replaceAll("\"", "");
		amountString = splitLine[3].replaceAll("\"", "");
		amount = Double.parseDouble(amountString);
		
		temp = new Transaction();
		temp.setAmount(amount);
		temp.setEntityName(entity);
		temp.setPayee(payee);
		temp.setPostingDate(date);
		
		transactionList.add(temp);
	}
	
	private static void processFile(){
		String inputLine;
		
		try (Scanner inputFile = new Scanner(new File ("transparency-download.csv"));){
			while (inputFile.hasNext()){
				inputLine = inputFile.nextLine();
				if (inputLine.startsWith("\"")){
					processLine(inputLine);
				}
			}
		}
		catch(FileNotFoundException fnf){
			System.out.println("File not found!");
		}
		catch(NoSuchElementException nsef){
			System.out.println("No line found!");
		}
	}
	
	private static BigDecimal calculateAmount(){
		BigDecimal sumAmount = new BigDecimal(0);
		for (int i = 0; i < transactionList.size(); i++){
			sumAmount = sumAmount.add(new BigDecimal((transactionList.get(i).getAmount())));
		}
		
		return sumAmount;
	}
	
	private static int findHowManyOfAEntityName(){
		int howMany = 0;
		for (int i = 0; i < transactionList.size(); i++){
			if (transactionList.get(i).getPayee().equals("NAME REDACTED")){
				howMany++;
			}
		}
		
		return howMany;
	}
	
	public static void main(String[] args){
		System.out.println("Processing....");
		processFile();
		
		System.out.println("The total amount is " + calculateAmount().toString() + ".");
		System.out.println("There were " + findHowManyOfAEntityName() + " Mr. Name Redacteds.");		
	}

}
