package tiepo.CIS494.A4;

import java.util.LinkedList;
import java.util.Stack;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class GUIController {

	@FXML
	private Button btnTest;
	@FXML
	private TextField txtString;
	@FXML
	private TextArea txtPrompt;
	
	@FXML 
	private void btnTestOnAction(ActionEvent e){
		String palindrome = txtString.getText();
		String strQueued = "";
		String strStacked = "";
		String result = "";
		Stack<Character> stack = new Stack<Character>();
		LinkedList<Character> queue = new LinkedList<Character>();
		
		if (!palindrome.isEmpty()){
			
			for (int i = 0; i < palindrome.length(); i++){
                stack.push(palindrome.charAt(i));
                queue.add(palindrome.charAt(i));
			}
			
			while (!queue.isEmpty()) {
	            strQueued = strQueued + queue.poll();
	        }
			
			while (!stack.isEmpty()) {
	            strStacked = strStacked + stack.pop();
	        }
			
			if (removeSpacesAndPunctuation(strQueued).equals(removeSpacesAndPunctuation(strStacked)))
				result = "Queue output is the same as Stack output. The string is a palindrome!";
			else
				result = "Queue output is not the same as Stack output. The string is NOT a palindrome!";
			
			txtPrompt.setText("String Queue \"polled\": " + strQueued + "\n" +
						"String Staked \"popped\": " + strStacked + "\n" + result);
		}
	}
	
	private String removeSpacesAndPunctuation(String quote){
		return quote.replaceAll("[^a-zA-Z]", "").toLowerCase();
	}
	
	@FXML 
	private void initialize(){
		System.out.println("Initializing!");
		txtPrompt.setEditable(false);
		txtString.requestFocus();
	}
}
