package application;
	
import java.io.File;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.Scanner;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;


public class Students extends Application {

	private HBox buildUserLine(String name, String id, String url){
		GridPane recordPane = new GridPane();
		recordPane.setPadding(new Insets(15,15,15,15));
		recordPane.setHgap(50);
		recordPane.setVgap(15);
		
		Font standardFont = new Font("Tahoma", 16);

		Label nameLabel = new Label("Name");
		nameLabel.setFont(standardFont);
		
		TextField nameTextField = new TextField();
		nameTextField.setText(name);

		Label idLabel = new Label("ID");
		idLabel.setFont(standardFont);
		
		TextField idTextField = new TextField();
		idTextField.setText(id);
		
		Image image = new Image(url);
		ImageView imageView = new ImageView(image);
		imageView.setFitWidth(80);
		imageView.setFitHeight(80);

		recordPane.add(nameLabel, 0, 0);
		recordPane.add(nameTextField, 1, 0);
		recordPane.add(idLabel, 0, 1);
		recordPane.add(idTextField, 1, 1);
		
		HBox outputPane = new HBox();
		outputPane.setAlignment(Pos.CENTER);
		outputPane.getChildren().addAll(recordPane, imageView);
		
		return outputPane;
	}
	
	private HBox processLine(String line){
		String[] splitLine = line.split(",");
		String name = splitLine[0];
		String id = splitLine[1];
		String url = splitLine[2];
		
		return buildUserLine(name, id, url);
	}
	
	private VBox loadStudents(){
		String inputLine;
		VBox pane = new VBox();
		
		try (Scanner inputFile = new Scanner(new File("Students.txt"))) {
			while(inputFile.hasNextLine()){
				inputLine = inputFile.nextLine();
				HBox tmpHBox = processLine(inputLine);
				pane.getChildren().add(tmpHBox); 
			}
		}
		catch(FileNotFoundException ex){
			System.out.println(ex.getMessage());
		}
		catch(NoSuchElementException ex){
			System.out.println(ex.getMessage());
		}
		
		return pane;
	}
	
	@Override
	public void start(Stage stage) throws Exception {
		VBox pane = loadStudents();
		Scene scene = new Scene(pane, 400, 300);
		stage.setScene(scene);
		stage.show();			
	}
	
	public static void main(String[] args) {
		Application.launch(args);
	}
}
