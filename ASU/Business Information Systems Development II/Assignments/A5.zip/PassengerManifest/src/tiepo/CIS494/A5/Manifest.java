package tiepo.CIS494.A5;

public class Manifest {

	public static void main(String[] args) {
		PassengerSystem ps = new PassengerSystem();
		ps.runPassengerSytem();
	}

}
