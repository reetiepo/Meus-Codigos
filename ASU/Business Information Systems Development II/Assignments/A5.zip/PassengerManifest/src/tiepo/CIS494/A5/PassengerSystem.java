package tiepo.CIS494.A5;

import java.util.PriorityQueue;
import java.util.Scanner;

public class PassengerSystem {
		
	PassengerComparator comparator = new PassengerComparator();
	
	public PriorityQueue<Passenger> passengerManifest = new PriorityQueue<>(comparator);
	
	public void addPassenger(){
		String name;
		float miles;
		int ticketCode;

		Scanner s = new Scanner(System.in);
		
		System.out.print("\nEnter a Passenger name: ");	
		name = s.nextLine();
		System.out.print("Enter SkyHigh program miles (in thousands): ");
		miles = s.nextFloat();
		System.out.print("Ticket code (0 - Excursion / 1 - Business / 2 - First class): ");		
		ticketCode = s.nextInt();
		
		Passenger passenger = new Passenger(name, miles, ticketCode);
		passengerManifest.add(passenger);
	}
	
	public void runPassengerSytem(){
		int count = 0;
		int bumpOff;
		String aux = "y";

		Scanner s = new Scanner(System.in);
		
		do{
			addPassenger();
			count++;
			System.out.println("Do you want to enter a new passenger (y/n)? ");
			aux = s.nextLine();
		}while(aux == "y");

		System.out.printf("\n *******There are a total of %d passengers.\n", count);
		System.out.println(" *******We may be overbooked! How many passengers would you like to bump off?");
		bumpOff = s.nextInt();
		
		if (bumpOff > 0){
			System.out.println("\nThe following passengers have been taken off the boarding list:");
			Passenger tempPassenger;
			
			for (int i = 0; i < bumpOff; i++){
				tempPassenger = passengerManifest.poll();
				System.out.printf("%s : %.1f\n", tempPassenger.getName(), tempPassenger.getMiles());
			}
		}
		
		System.out.printf("\n**********\nFinal Boarding\n**********\n\n");
		
		for (Passenger passenger : passengerManifest){
			System.out.printf("%s : %.1f\n", passenger.getName(), passenger.getMiles());
		}
	}
}
