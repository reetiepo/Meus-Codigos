package tiepo.CIS494.A5;

import java.util.Comparator;

public class PassengerComparator implements Comparator<Passenger> {

	public int compare(Passenger passenger1, Passenger passenger2) {
		if (passenger1.getTicketCode() == passenger2.getTicketCode())
			return (int) (passenger1.getMiles() - passenger2.getMiles());
		return passenger1.getTicketCode() - passenger2.getTicketCode();
	}
}
