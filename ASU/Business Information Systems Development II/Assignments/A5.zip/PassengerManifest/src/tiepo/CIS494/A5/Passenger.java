package tiepo.CIS494.A5;

public class Passenger {

	private String name;
	
	private float miles;
	
	private int ticketCode;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getMiles() {
		return miles;
	}

	public void setMiles(float miles) {
		this.miles = miles;
	}

	public int getTicketCode() {
		return ticketCode;
	}

	public void setTicketCode(int ticketCode) {
		this.ticketCode = ticketCode;
	}
	
	public Passenger(String pName, float pMiles, int pTicketCode){
		name = pName;
		miles = pMiles;
		ticketCode = pTicketCode;
	}
	
}
