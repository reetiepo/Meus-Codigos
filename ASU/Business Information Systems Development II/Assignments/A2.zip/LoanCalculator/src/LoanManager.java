import java.util.Scanner;

public class LoanManager {

	private static GenericLoan[] listOfLoans;
	private static int numberOfLoans;
	
	public static void main(String[] args) {
		listOfLoans = new GenericLoan[10];
		numberOfLoans = 0;
		System.out.println("\t\t\tFirst National Loans");
		showMenu();
	}
	
	private static void showMenu(){
		Scanner s = new Scanner(System.in);
		String input = "";
		
		do {
			double loanAmount;
			int numOfYears, fico;
			System.out.print("Do you want to apply for a (A)uto loan or a (M)ortgage? ");
			input = s.nextLine();
			input = input.toUpperCase();
			if(input.equals("X"))
				break;
			
			switch(input){
				case "A":
					AutoLoan autoLoanTemp;
					System.out.print("Enter loan amount: ");
					loanAmount = s.nextDouble();
					System.out.print("Enter number of years: ");
					numOfYears = s.nextInt();
					
					autoLoanTemp = new AutoLoan(numOfYears, loanAmount);
					listOfLoans[numberOfLoans] = autoLoanTemp;
					numberOfLoans++;
					System.out.printf("The totally payment on this loan will be %1$.2f. \n", autoLoanTemp.totalPayment());
					break;
				case "M":
					MortgageLoan mortgageLoanTemp = new MortgageLoan();
					System.out.print("Enter loan amount: ");
					loanAmount = s.nextDouble();
					System.out.print("Enter number of years: ");
					numOfYears = s.nextInt();
					System.out.print("Enter FICO score: ");
					fico = s.nextInt();
	 
					mortgageLoanTemp.setLoanAmount(loanAmount);
					mortgageLoanTemp.setNumOfYears(numOfYears);
					mortgageLoanTemp.setFicoScore(fico);
					listOfLoans[numberOfLoans] = mortgageLoanTemp;
					numberOfLoans++;
					System.out.printf("The totally payment on this loan will be %1$.2f. \n", mortgageLoanTemp.totalPayment());
					break;
				default:
					break;
			}
		} while (! input.equalsIgnoreCase("X"));
		
		s.close();
		printLoanList();
	}
	
	private static void printLoanList(){
		System.out.println("\nFollowing are the loans in the system:");
		
		for(int i = 0; i < numberOfLoans; i++){

			System.out.printf("Amount: %1$.2f", listOfLoans[i].getLoanAmount());
			
			if (listOfLoans[i] instanceof MortgageLoan){
				MortgageLoan tmpMortgageLoan = (MortgageLoan)listOfLoans[i];
				System.out.printf("\tFICO: " + tmpMortgageLoan.getFicoScore());
			}
			
			System.out.println();
		}
	}

}
