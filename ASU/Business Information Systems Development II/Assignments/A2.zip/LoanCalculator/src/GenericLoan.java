
public abstract class GenericLoan {

	private int numOfYears;
	private double annualInterestRate;
	private double loanAmount;
	
	public int getNumOfYears() {
		return numOfYears;
	}
	
	public void setNumOfYears(int numOfYears) {
		this.numOfYears = numOfYears;
	}

	public double getAnnualInterestRate() {
		return annualInterestRate;
	}

	public void setAnnualInterestRate(double annualInterestRate) {
		this.annualInterestRate = annualInterestRate;
	}
	
	public double getLoanAmount() {
		return loanAmount;
	}
	
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	
	public abstract double monthlyPayment();
	
	public abstract double totalPayment();
}
