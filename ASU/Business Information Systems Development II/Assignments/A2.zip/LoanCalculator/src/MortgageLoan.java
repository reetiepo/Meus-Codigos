
public class MortgageLoan extends GenericLoan {

	private int ficoScore;
	
	public MortgageLoan() {
		// TODO Auto-generated constructor stub
		ficoScore = 600;
	}

	public int getFicoScore() {
		return ficoScore;
	}

	public void setFicoScore(int ficoScore) {
		this.ficoScore = ficoScore;
	}
	
	public double monthlyPayment(){
		if (ficoScore < 700){
			setAnnualInterestRate(6.5);
		}
		else{
			setAnnualInterestRate(4.0);
		}
		
		double monthlyInterestRate = getAnnualInterestRate() / 1200;
		
		return getLoanAmount() * monthlyInterestRate / (1 -
				 (Math.pow(1 / (1 + monthlyInterestRate), getNumOfYears() * 12)));
	}
	
	public double totalPayment(){
		return monthlyPayment() * 12 * getNumOfYears();
	}
}
