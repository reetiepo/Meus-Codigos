
public class AutoLoan extends GenericLoan {

	public AutoLoan(int numOfYears, double loanAmount) {
		// TODO Auto-generated constructor stub
		setAnnualInterestRate(5.0);
		setNumOfYears(numOfYears);
		setLoanAmount(loanAmount);
	}
	
	public double monthlyPayment(){
		double monthlyInterestRate = getAnnualInterestRate() / 1200;
		
		return getLoanAmount() * monthlyInterestRate / (1 -
				 (Math.pow(1 / (1 + monthlyInterestRate), getNumOfYears() * 12)));
	}
	
	public double totalPayment(){
		return monthlyPayment() * 12 * getNumOfYears();
	}

}
