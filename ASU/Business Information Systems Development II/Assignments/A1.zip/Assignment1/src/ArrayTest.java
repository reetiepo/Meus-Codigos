import java.util.Random;
public class ArrayTest {

	public static void main(String[] args) {
		ArrayTest at = new ArrayTest();
		
		System.out.println("Part 1: Copying Arrays");
		int[] testSourceArray  = {0, 1, 2, 3, 4};
		int[] testTargetArray = new int[5];
		at.copyArray(testSourceArray, testTargetArray);
		System.out.print("Old array values: ");
		for (int i = 0; i < testSourceArray.length; i++){
			System.out.print(testSourceArray[i] + " ");
		}
		System.out.println();
		System.out.print("Copied array values: ");
		for (int i = 0; i < testTargetArray.length; i++){
			System.out.print(testTargetArray[i] + " ");
		}
		System.out.println("\n");
		
		System.out.println("Part 2: Joining Arrays");
		int[] joinedArray = at.joinArrays(testSourceArray, testTargetArray);
		System.out.print("Joined array valeus: ");
		for (int i = 0; i < joinedArray.length; i++){
			System.out.print(joinedArray[i] + " ");
		}
		System.out.println("\n");
		
		System.out.println("Part 3: Generate Randoms");
		at.generateRandoms();
	}

	private void copyArray(int[] sourceArray, int[] targetArray){
		for (int i = 0; i < sourceArray.length; i++){
			targetArray[i] = sourceArray[i];
		}
	}
	
	private int[] joinArrays(int[] array1, int[] array2){
		int[] joinedArray = new int[array1.length + array2.length];
		int i, j;
		
		for (i = 0; i < array1.length; i++){
			joinedArray[i] = array1[i];
		}
		
		for (j = 0; j < array2.length; j++){
			joinedArray[i+j] = array2[j];
		}
		
		return joinedArray;
	}
	
	private void generateRandoms(){
		Random r = new Random();
		int[] howOftenArray = new int[10]; //stores how often a number is generated
		int number;
		
		for (int i = 0; i < 100; i++){
			number = r.nextInt(10);
			howOftenArray[number]++;
		}
		
		for (int i = 0; i < howOftenArray.length; i++){
			System.out.println(i + ":\t" + howOftenArray[i]);
		}
	}
}
