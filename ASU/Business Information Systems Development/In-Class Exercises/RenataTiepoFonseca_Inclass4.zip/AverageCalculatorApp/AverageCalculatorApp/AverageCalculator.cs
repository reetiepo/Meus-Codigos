﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AverageCalculatorApp
{
    class AverageCalculator
    {
        // Inclass 4, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        static int[,] scoreArray = new int[4,3];

        private static void PopulateTestScores()
        {
            // loop through all rows
            for (int i = 0; i < scoreArray.GetLength(0); i++)
            {
                Console.WriteLine("Enter Scores for Student {0}", i + 1);
                // for each row, loop through all columns
                for (int j = 0; j < scoreArray.GetLength(1); j++)
                {
                    Console.Write("Score {0}: ", j + 1);
                    scoreArray[i, j] = Convert.ToInt32(Console.ReadLine());
                }
                Console.WriteLine();
            }
        }

        private static void CalculateTestAverage()
        {
            int total = 0;
            double average = 0.0;

            for (int i = 0; i < scoreArray.GetLength(0); i++)
            {
                for (int j = 0; j < scoreArray.GetLength(1); j++)
                {
                    total += scoreArray[i, j];
                }
            }

            average = (double)total / scoreArray.Length;

            Console.WriteLine("The class average for all test is {0:f2}.", average);
        }

        static void Main(string[] args)
        {
            PopulateTestScores();
            CalculateTestAverage();
            Console.ReadLine();
        }
    }
}
