﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;

namespace ExcelObjects
{
    public partial class ExcelObjects : Form
    {
        // In-class 13, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        Excel.Application oXL; // Excel application object
        Excel._Workbook oWB; // Excel Workbook object
        Excel._Worksheet oSheet; // Excel Worksheet object
        Excel._Worksheet oSheet2; // Excel Worksheet object

        public ExcelObjects()
        {
            InitializeComponent();
        }

        private void openButton_Click(object sender, EventArgs e)
        {
            oXL = new Excel.Application();
            oXL.Visible = true;

            oWB = (Excel._Workbook)(oXL.Workbooks.Add());
            oSheet = (Excel._Worksheet)oWB.ActiveSheet;

            oSheet.Cells[1, 1] = "First Name";
            oSheet.Cells[1, 2] = "Last Name";
            oSheet.Cells[2, 1] = "Renata";
            oSheet.Cells[2, 2] = "Tiepo Fonseca";
            oSheet.Cells[3, 1] = "Joao Pedro";
            oSheet.Cells[3, 2] = "Santos de Moura";
            oSheet.Cells[4, 1] = "Izabela";
            oSheet.Cells[4, 2] = "Fontes Avolio";

            oSheet2 = (Excel._Worksheet)oWB.Worksheets.Add();
            oSheet2.Name = "Average Calculator";
            oSheet2.Move(Missing.Value, oSheet);

            for (int i = 1; i <= 5; i++)
            {
                oSheet2.Cells[i, 2] = i;
            }

            oSheet2.Cells[6, 1] = "Average";
            oSheet2.Cells[6, 2] = "=AVERAGE(B1:B5)";
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            oWB.SaveAs("MyExcel.xlsx"); 
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            oWB.Close();
            oXL.Quit();
        }
    }
}
