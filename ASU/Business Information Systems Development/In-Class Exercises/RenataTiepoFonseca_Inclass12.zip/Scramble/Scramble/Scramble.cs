﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JumbleLibrary;

namespace Scramble
{
    public partial class Scramble : Form
    {
        // In-class 12, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        private string[] scrambledWordArray;

        private string[] unScrambledWordArray;

        private Label[] sourceLabels;

        private Label[] destinationLabels;

        private JumbleCreator Jumbler;

        private int numberOfErrorsLeft = 3;

        public Scramble()
        {
            InitializeComponent();
        }

        private void Scramble_Load(object sender, EventArgs e)
        {
            wordDescriptionLabel.Visible = false;
            errorsLeftLable.Visible = false;
        }

        private void SourceLabels_MouseDown(object sender, MouseEventArgs e)
        {
            Label tmpLabel = (Label)sender;
            DoDragDrop(tmpLabel, DragDropEffects.Move);
        }

        private void DestinationLabels_DragEnter(object sender, DragEventArgs e)
        {
            bool isLabel = e.Data.GetDataPresent(typeof(Label));

            if (isLabel)
                e.Effect = DragDropEffects.Move;
        }

        private void DestinationLabels_DragDrop(object sender, DragEventArgs e)
        {
            Label tmpDestination = (Label)sender;
            Label tmpSource = (Label)e.Data.GetData(typeof(Label));

            if (tmpDestination.Tag.ToString() == tmpSource.Text)
            {
                tmpDestination.Text = tmpSource.Text;
                tmpSource.Visible = false;
            }
            else
            {
                numberOfErrorsLeft--;
                errorsLeftLable.Text = "Errors left: " + numberOfErrorsLeft.ToString() + ".";

                if (numberOfErrorsLeft < 2)
                    errorsLeftLable.ForeColor = Color.Red;

                if (numberOfErrorsLeft == 0)
                {
                    errorsLeftLable.Text = "You lose.";

                    for (int i = 0; i < destinationLabels.Length; i++)
                        destinationLabels[i].Enabled = false;
                }

            }
        }

        private void LoadWords()
        {
            Jumbler = new JumbleCreator();

            scrambledWordArray = Jumbler.GetScrambledWord();
            unScrambledWordArray = Jumbler.GetUnScrambledWord();

            numberOfErrorsLeft = 3;
            errorsLeftLable.Text = "Errors left: " + numberOfErrorsLeft.ToString() + ".";
            errorsLeftLable.ForeColor = Color.Black;
            errorsLeftLable.Visible = true;

            wordDescriptionLabel.Text = Jumbler.GetWordDescription();
            wordDescriptionLabel.AutoSize = true;
            wordDescriptionLabel.Visible = true;

            int arrayLenght = scrambledWordArray.Length;
            sourceLabels = new Label[arrayLenght];
            destinationLabels = new Label[arrayLenght];
            int labelLeftEdge = 50;

            for (int i = 0; i < arrayLenght; i++)
            {
                Label tmpLabel = new Label();
                tmpLabel.Font = new Font("Come Sans MS", 11);
                tmpLabel.Text = scrambledWordArray[i].ToString();
                tmpLabel.AutoSize = true;
                tmpLabel.Left = labelLeftEdge;
                labelLeftEdge += 80;
                tmpLabel.Top = 200;
                tmpLabel.Visible = true;

                tmpLabel.MouseDown += new MouseEventHandler(this.SourceLabels_MouseDown);
                Controls.Add(tmpLabel);
                sourceLabels[i] = tmpLabel;
            }

            labelLeftEdge = 50;

            for (int i = 0; i < arrayLenght; i++)
            {
                Label tmpLabel = new Label();
                tmpLabel.Font = new Font("Come Sans MS", 11);
                tmpLabel.Text = "___";
                tmpLabel.AutoSize = true;
                tmpLabel.Tag = unScrambledWordArray[i].ToString();
                tmpLabel.Top = 100;
                tmpLabel.Left = labelLeftEdge;
                labelLeftEdge += 80;
                tmpLabel.AllowDrop = true;

                tmpLabel.DragDrop += new DragEventHandler(this.DestinationLabels_DragDrop);
                tmpLabel.DragEnter += new DragEventHandler(this.DestinationLabels_DragEnter);
                
                Controls.Add(tmpLabel);
                destinationLabels[i] = tmpLabel;
            }
        }

        private void newGameButton_Click(object sender, EventArgs e)
        {
            for (int i = Controls.Count - 1; i >= 0; i--)
            {
                if (Controls[i] is Label 
                    && Controls[i].Name != "wordDescriptionLabel" 
                    && Controls[i].Name != "errorsLeftLable")
                {
                    Controls[i].Dispose();
                }
            }

            sourceLabels = destinationLabels = null;
            scrambledWordArray = unScrambledWordArray = null;
            Jumbler = null;
            errorsLeftLable.Visible = false;
            LoadWords();
        }
    }
}
