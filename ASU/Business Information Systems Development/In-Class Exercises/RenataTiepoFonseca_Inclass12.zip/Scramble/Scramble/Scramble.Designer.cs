﻿namespace Scramble
{
    partial class Scramble
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wordDescriptionLabel = new System.Windows.Forms.Label();
            this.errorsLeftLable = new System.Windows.Forms.Label();
            this.newGameButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // wordDescriptionLabel
            // 
            this.wordDescriptionLabel.AutoSize = true;
            this.wordDescriptionLabel.Location = new System.Drawing.Point(354, 30);
            this.wordDescriptionLabel.Name = "wordDescriptionLabel";
            this.wordDescriptionLabel.Size = new System.Drawing.Size(109, 13);
            this.wordDescriptionLabel.TabIndex = 0;
            this.wordDescriptionLabel.Text = "wordDescriptionLabel";
            // 
            // errorsLeftLable
            // 
            this.errorsLeftLable.AutoSize = true;
            this.errorsLeftLable.Location = new System.Drawing.Point(357, 370);
            this.errorsLeftLable.Name = "errorsLeftLable";
            this.errorsLeftLable.Size = new System.Drawing.Size(100, 13);
            this.errorsLeftLable.TabIndex = 1;
            this.errorsLeftLable.Text = "You have x tries left";
            // 
            // newGameButton
            // 
            this.newGameButton.Location = new System.Drawing.Point(360, 396);
            this.newGameButton.Name = "newGameButton";
            this.newGameButton.Size = new System.Drawing.Size(97, 23);
            this.newGameButton.TabIndex = 2;
            this.newGameButton.Text = "Start New Game";
            this.newGameButton.UseVisualStyleBackColor = true;
            this.newGameButton.Click += new System.EventHandler(this.newGameButton_Click);
            // 
            // Scramble
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 461);
            this.Controls.Add(this.newGameButton);
            this.Controls.Add(this.errorsLeftLable);
            this.Controls.Add(this.wordDescriptionLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Scramble";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Scramble!";
            this.Load += new System.EventHandler(this.Scramble_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label wordDescriptionLabel;
        private System.Windows.Forms.Label errorsLeftLable;
        private System.Windows.Forms.Button newGameButton;
    }
}

