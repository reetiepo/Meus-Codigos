﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpendingCalculatorApp
{
    class SpendingCalculator
    {

        // Inclass 3, Renata Tiepo Fonseca , CIS 345, Monday/Wednesday 3:00 PM

        static void Main(string[] args)
        {
            int totalDollars = 100;
            int leftoverChange, perDiem, numberOfDays;
            leftoverChange = perDiem = numberOfDays = 0;
            Console.WriteLine("You have ${0}", totalDollars);
            perDiem = CalculatePerDiem(totalDollars, ref leftoverChange);
            Console.WriteLine("With {0} dollars, your per diem is ${1}, per day over 5 days with ${2} left.\n", totalDollars, perDiem, leftoverChange);

            Console.Write("How many days is your trip? ");
            numberOfDays = Convert.ToInt32(Console.ReadLine());
            perDiem = CalculatePerDiem(totalDollars, ref leftoverChange, numberOfDays);
            Console.WriteLine("With {0} dollars, your per diem is ${1}, per day over {2} days with ${3} left.\n", totalDollars, perDiem, numberOfDays, leftoverChange);
            Console.ReadLine();
        }

        private static int CalculatePerDiem(int dollars, ref int change, int days = 5)
        {
            change = dollars % days;
            return dollars / days;
        }

    }
}
