﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JaggedArrayApp
{
    class JaggedArray
    {
        // Inclass 5, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        private static void ReadScores(int studentNumber, int[] scoreArray)
        {
            for (int i = 0; i < scoreArray.Length; i++)
            {
                Console.Write("Enter score {0} for student {1}: ", i + 1, studentNumber);
                scoreArray[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("\n");
        }

        private static void PrintAllScores(int[][] scoresArray)
        {
            double average;

            Console.WriteLine("Following were the scores entered:\n");

            for (int i = 0; i < scoresArray.Length; i++)
            {
                average = 0;
                Console.WriteLine("Student {0}", i + 1);
                for (int j = 0; j < scoresArray[i].Length; j++)
                {
                    average += scoresArray[i][j];
                    Console.Write("{0} ", scoresArray[i][j]);
                }
                average = average / scoresArray[i].Length;
                Console.WriteLine("\nAverage: {0:f2}\n", average);
            }
        }

        private static void PrintAveragePerScore(int scoreNumber, int[][] scoresArray)
        {
            int students = 0;
            double average = 0;

            for (int i = 0; i < scoresArray.Length; i++)
            {
                if (scoresArray[i].Length >= scoreNumber)
                {
                    students++;
                    average += scoresArray[i][scoreNumber-1];
                }
            }

            average = average / students;
            Console.WriteLine("Average for score {0} is: {1:f2}", scoreNumber, average);
        }

        static void Main(string[] args)
        {
            int[][] jaggedArray;
            jaggedArray = new int[3][];
            int scoreCount = 0;
            int scoreNumber = 0;

            for (int i = 0; i < jaggedArray.Length; i++)
            {
                Console.Write("How many scores for student {0}? ", i + 1);
                scoreCount = Convert.ToInt32(Console.ReadLine());

                jaggedArray[i] = new int[scoreCount];
                ReadScores(i + 1, jaggedArray[i]);
            }

            PrintAllScores(jaggedArray);

            Console.Write("For what score do you want to calculate the average? ");
            scoreNumber = Convert.ToInt32(Console.ReadLine());
            PrintAveragePerScore(scoreNumber, jaggedArray);

            Console.ReadLine();
        }
    }
}
