﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DieRollApp
{
    class RollDie
    {

        //Inclass 2, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        static void Main(string[] args)
        {
            int DieValue;
            String FaceText;
            ConsoleKeyInfo key;

            Console.WriteLine("Press Enter to roll a die (Press Esc to exit).");
            do{
                key = Console.ReadKey();

                if (key.Key != ConsoleKey.Escape)
                {
                    DieValue = GenerateRandomNumber();
                    FaceText = NumbertoText(DieValue);

                    Console.WriteLine("You rolled a {0}", FaceText);
                }
            } while (key.Key != ConsoleKey.Escape);
        }

        static String NumbertoText(int number)
        {
            String NumberText = "";

            switch (number)
            {
                case 1: NumberText = "ONE"; break;
                case 2: NumberText = "TWO"; break;
                case 3: NumberText = "THREE"; break;
                case 4: NumberText = "FOUR"; break;
                case 5: NumberText = "FIVE"; break;
                case 6: NumberText = "SIX"; break;
            }

            return NumberText;
        }

        static int GenerateRandomNumber()
        {
            int DieFace;
            Random randomNumbers = new Random();
            DieFace = randomNumbers.Next(1,7);
            return DieFace;
        }            
    }
}
