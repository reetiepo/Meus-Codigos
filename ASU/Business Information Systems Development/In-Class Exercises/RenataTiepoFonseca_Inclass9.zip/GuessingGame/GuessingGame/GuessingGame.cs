﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuessingGame
{
    public partial class GuessingGame : Form
    {
        // In-class 9, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        private int secretAnswer, numberOfTries, userGuess;

        public GuessingGame()
        {
            InitializeComponent();
        }

        private void GuessingGame_Load(object sender, EventArgs e)
        {
            // Starting the min and max values of the progress bar
            progressBar.Minimum = 0;
            progressBar.Maximum = 3;

            StartNewGame();
        }

        // Deactivate the games button and activate the button to start new game
        private void DeactivateGame()
        {
            okButton.Enabled = false;
            guessTextBox.Enabled = false;
            startNewGameButton.Enabled = true;
        }

        private void StartNewGame()
        {
            // Generate a new random number from 1 to 10
            Random rand = new Random();
            secretAnswer = rand.Next(1, 11);

            // Starts the game settings
            okButton.Enabled = true;
            startNewGameButton.Visible = false;
            numberOfTries = 1;
            progressBar.Value = numberOfTries;
            guessLabel.Text = "Guess " + numberOfTries + "/3";
            statusLabel.Text = "Guess a number between 1 and 10.";
            guessTextBox.Enabled = true;
            guessTextBox.Text = "";
            guessTextBox.Focus();
        }

        private void ProcessMove()
        {
            // Verifies if the user guess it right
            if (userGuess == secretAnswer)
            {
                statusLabel.Text = "You win!";
                DeactivateGame();
            }
            else
            {
                // Shows if the guess was too high or too low
                if (userGuess > secretAnswer)
                    statusLabel.Text = userGuess + " was too high.";
                else
                    statusLabel.Text = userGuess + " was too low.";

                // Arrange the settings to the next guess
                guessTextBox.Text = "";
                guessTextBox.Focus();
                progressBar.Value = numberOfTries;
                guessLabel.Text = "Guess " + numberOfTries + "/3";
                numberOfTries++;

                // If the user reached the max number of guesses the game is deactivate
                if (numberOfTries == 4)
                {
                    statusLabel.Text = "The answer was " + secretAnswer + ". You lose.";
                    DeactivateGame();
                }
            }
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            // Sets the guess number and process to the next move
            userGuess = Convert.ToInt32(guessTextBox.Text);
            if (numberOfTries <= 3)
                ProcessMove();
        }

        private void startNewGameButton_Click(object sender, EventArgs e)
        {
            StartNewGame();
        }
    }
}
