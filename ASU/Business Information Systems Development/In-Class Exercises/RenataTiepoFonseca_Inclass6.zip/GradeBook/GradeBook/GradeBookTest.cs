﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradeBook
{
    class GradeBookTest
    {
        // Inclass 6, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        public static void Main(string[] args)
        {
            GradeBook gradeBook345 = new GradeBook();
            GradeBook gradeBook425 = new GradeBook();

            gradeBook345.CourseNumber = 345;
            gradeBook345.CollegeName = "ASU";

            gradeBook425.CourseNumber = 425;
            //gradeBook425.CollegeName = "ASU";

            //ClassAverage does not have the set acessor so it is read-only
            //gradeBook345.ClassAverage = 85;
            //gradeBook425.ClassAverage = 85;

            gradeBook345.ClassSize = 45;
            gradeBook425.ClassSize = 30;

            Console.WriteLine("Initial course name is: '{0}'", gradeBook345.CourseName);
            Console.Write("Please enter the course name: ");
            gradeBook345.CourseName = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("A new grade book was created for {0} at {1}. This class size is {2}.",
                               gradeBook345.CourseNumber, gradeBook345.CollegeName, gradeBook345.ClassSize);
            gradeBook345.DisplayMessage();

            Console.WriteLine();

            Console.WriteLine("Initial course name is: '{0}'", gradeBook425.CourseName);
            Console.Write("Please enter the course name: ");
            gradeBook425.CourseName = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("A new grade book was created for {0} at {1}. This class size is {2}.",
                               gradeBook425.CourseNumber, gradeBook425.CollegeName, gradeBook425.ClassSize);
            gradeBook425.DisplayMessage();

            Console.ReadLine();
        }
    }
}
