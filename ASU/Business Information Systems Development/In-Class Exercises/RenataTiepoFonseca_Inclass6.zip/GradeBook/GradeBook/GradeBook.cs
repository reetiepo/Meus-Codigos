﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradeBook
{
    class GradeBook
    {
        // Inclass 6, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        private int courseNumber;

        public int CourseNumber
        {
            get { return courseNumber; }
            set
            {
                if (value > 100 || value < 500)
                    courseNumber = value;
            }
        }

        private static string collegeName;

        public string CollegeName
        {
            get { return collegeName; }
            set { collegeName = value; }
        }

        private double classAverage = 0.0;

        public double ClassAverage
        {
            get { return classAverage; }
        }

        public int ClassSize { get; set; }

        private string courseName;

        public string CourseName
        {
            get
            {
                return courseName;
            }
            set
            {
                courseName = value;
            }
        }

        public void DisplayMessage()
        {
            Console.WriteLine("Welcome to the grade book for\n{0}!", CourseName);
        }
    }
}
