﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Paint
{
    public partial class Paint : Form
    {
        // In-class 11, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        private Color penColor;
        private Pen myPen;
        private Point previousPoint, currentPoint;
        private Graphics myGraphics;
        private bool keepDrawing;

        public Paint()
        {
            InitializeComponent();
        }

        private void Paint_Load(object sender, EventArgs e)
        {
            previousPoint = new Point();
            currentPoint = new Point();

            penColor = Color.Black;
            keepDrawing = false;
            myPen = new Pen(penColor);
            myGraphics = this.CreateGraphics();
        }

        private void RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (blackRadioButton.Checked)
                penColor = Color.Black;
            else if (blueRadioButton.Checked)
                penColor = Color.Blue;
            else if (greenRadioButton.Checked)
                penColor = Color.Green;
            else if (redRadioButton.Checked)
                penColor = Color.Red;

            if (smallRadioButton.Checked)
                myPen.Width = 2;
            else if (mediumRadioButton.Checked)
                myPen.Width = 4;
            else if (largeRadioButton.Checked)
                myPen.Width = 6;
        }

        private void Paint_MouseDown(object sender, MouseEventArgs e)
        {
            keepDrawing = true;

            Point newPoint = new Point(e.X, e.Y);
            currentPoint = newPoint;
        }

        private void Paint_MouseUp(object sender, MouseEventArgs e)
        {
            keepDrawing = false;
        }

        private void Paint_MouseMove(object sender, MouseEventArgs e)
        {
            if (keepDrawing)
            {
                previousPoint = currentPoint;
                Point newPoint = new Point(e.X, e.Y);
                currentPoint = newPoint;

                myPen.Color = penColor;
                myGraphics.DrawLine(myPen, previousPoint, currentPoint);
            }
        }

        private void dottedCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (dottedCheckBox.Checked)
                myPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
            else
                myPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            myGraphics.Clear(Color.White);
        }
    }
}
