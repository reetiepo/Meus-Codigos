﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentSystem
{
    class StudentSytem
    {
        // In-class 7, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        private static Student[] studentRoster;

        static void Main(string[] args)
        {
            LoadStudents();

            Console.ReadLine();
        }

        private static void LoadStudents()
        {
            studentRoster = new Student[10];
            bool continueLoop = false;
            string studentName, studentID;
            int spaces = 0;

            do
            {
                continueLoop = false;
                Console.Write("Enter the Student Name: ");
                studentName = Console.ReadLine();
                Console.Write("Enter the Student ID: ");
                studentID = Console.ReadLine();

                Student student = new Student();
                student.CreateStudent(studentID, studentName);
                studentRoster[Student.StudentCount-1] = student;

                Console.Write("\nDo you wan to enter information for another student?\nEnter 'Y' for Yes. Any other key for No.");
                if (Console.ReadLine() == "Y")
                    continueLoop = true;
                Console.WriteLine();
            } while (continueLoop);

            Console.WriteLine("\n{0}{1,18}", "Name", "ID");

            for (int i = 0; i < Student.StudentCount; i++)
            {
                spaces = 20 - studentRoster[i].Name.Length + studentRoster[i].ID.Length;
                Console.WriteLine("{0}{1," + spaces + "}", studentRoster[i].Name, studentRoster[i].ID);
            }
        }
    }
}
