﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentSystem
{
    class Student
    {
        // In-class 7, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        private static int studentCount;

        public string Name { get; set; }

        public string ID { get; set; }

        public static int StudentCount { get { return studentCount; } }

        public void CreateStudent(string studentID)
        {
            ID = studentID;
            studentCount++;

            Console.WriteLine("A new student with ID #{0} has been created.", studentID);
            Console.WriteLine("There are now {0} students in the system.", studentCount);
        }

        public void CreateStudent(string studentID, string studentName)
        {
            ID = studentID;
            Name = studentName;
            studentCount++;

            Console.WriteLine("A new student, {0}, with ID #{1} has been created.",studentName, studentID);
            Console.WriteLine("There are now {0} students in the system.", studentCount);
        }



    }
}
