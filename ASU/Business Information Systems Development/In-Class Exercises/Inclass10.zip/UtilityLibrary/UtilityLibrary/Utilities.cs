﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UtilityLibrary
{
    public class Utilities
    {
        // Inclass 10, Renata Tiepo Fonseca, CIS 345, Monaday/Wednesday 3:00 PM

        public static int ReadInteger(string message)
        {
            int numberOfErrors = 0;
            int number = 0;
            bool promptUserAgain = false;

            do
            {
                try
                {
                    Console.Write(message);
                    number = Convert.ToInt32 (Console.ReadLine());

                    promptUserAgain = false;
                }
                catch (FormatException)
                {
                    if (numberOfErrors == 2)
                    {
                        Console.Write("You seen to be having issues. Press a key to exit the application.");
                        Console.ReadLine();
                        System.Environment.Exit(0);
                    }
                    else
                    {
                        Console.Write("Input must be numeric. Try again.\n");
                        promptUserAgain = true;
                        numberOfErrors++;
                    }
                }
            } while (promptUserAgain);

            return number;
        }
    }
}
