﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inclass1
{
    class Loops
    {
        //Inclass 1, Renata Tiepo Fonseca, CIS 345, Wednesday 3:00 PM

        static void Main(string[] args)
        {
            int level = 5;

            #region CIS 345 Inclass 1, Part 1

            for (int i = 1; i <= 10; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }

            Console.WriteLine();

            for (int i = 1; i <= 10; i++)
            {
                for (int j = 1; j <= i - 1; j++)
                {
                    Console.Write(" ");
                }
                for (int k = 10; k >= i; k--)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }

            Console.WriteLine();

            #endregion

            #region CIS 345 Inclass 1, Part 2

            for (int i = 1; i <= 10; i++)
            {
                for (int j = 1; j < i; j++)
                {
                    Console.Write(" ");
                }
                Console.Write("*");
                Console.WriteLine();
            }

            Console.WriteLine();

            for (int i = 1; i <= 10; i++)
            {
                for (int j = 10; j > i; j--)
                {
                    Console.Write(" ");
                }
                Console.Write("*");
                Console.WriteLine();
            }

            Console.WriteLine();

            #endregion

            #region CIS 345 Inclass 1, Part 3

            Console.WriteLine("I can build you a equilateral triangle! How many levels would you like?");
            level = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i <= level; i++)
            {
                for (int j = 30; j >= i; j--)
                {
                    Console.Write(" ");
                }
                for (int k = 1; k <= i + (i - 1); k++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }

            #endregion

            #region CIS 345 Inclass 1, Extra Exercise

            Console.WriteLine("I can build you a Tree! How many levels would you like?");
            level = Convert.ToInt32(Console.ReadLine());

            for (int n = 2; n <= level + 1; n++)
            {
                for (int i = 1; i <= n; i++)
                {
                    for (int j = 30; j >= i; j--)
                    {
                        Console.Write(" ");
                    }
                    for (int k = 1; k <= i + (i - 1); k++)
                    {
                        Console.Write("*");
                    }
                    Console.WriteLine();
                }
            }

            int treebody = (level / 2) + 1;

            if (treebody % 2 == 0)
            {
                treebody++;
            }

            for (int n = 1; n <= level; n++)
            {
                for (int j = 30 - (level / 2); j >= 0; j--)
                {
                    Console.Write(" ");
                }
                for (int i = 1; i <= treebody; i++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }

            #endregion

            Console.ReadKey();
        }
    }
}
