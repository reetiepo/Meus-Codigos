﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HomelandSecurity;

namespace CHARMS
{
    public partial class CHARMS : Form
    {
        // Project, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        // Declaration of the array of flights
        private Flight[] flightsArray;

        // Variable to control the number of flights added to the system
        private int numberOfFlightsAdded;

        // Variable to keep the index of the selected flight (it will be -1 if there is no selected flights)
        private int selectedFlight = -1;

        public CHARMS()
        {
            InitializeComponent();
        }

        private void CHARMS_Load(object sender, EventArgs e)
        {
            // Initializating the screen seeting the panel and the second menu options invisible and the first menu options visible
            menuToolStripMenuItem2.Visible = false;
            exitToCHARMSToolStripMenuItem.Visible = false;
            informationPanel.Visible = false;
            resultPanel.Visible = false;
            // Initializating the array of flights
            flightsArray = new Flight[30];
            numberOfFlightsAdded = 0;

            LoadSampleFlights();
        }
        
        /// <summary>
        /// Load 4 sample flights
        /// </summary>
        private void LoadSampleFlights()
        {
            // Populatin the arrays of flights and passengers
            flightsArray[0] = new Flight("Phoenix", "Chicago", "3245", 5);
            flightsArray[0].passengerArray[0] = new Passenger("Nicole", "Jones", "34244");
            flightsArray[0].passengerArray[0] = new Passenger("John", "Smith", "345532");
            flightsArray[0].passengerArray[1] = new Passenger("Clark", "Johnson", "443234");
            flightsArray[0].passengerArray[2] = new Passenger("James", "Williams", "343422");
            flightsArray[0].passengerArray[3] = new Passenger("Clark", "Smith", "435334");
            flightsArray[0].passengerArray[4] = new Passenger("Ashley", "Brown", "344542");
            flightsArray[1] = new Flight("Chicago", "Phoenix", "44832", 1);
            flightsArray[1].passengerArray[0] = new Passenger("John", "Smith", "345532");
            flightsArray[2] = new Flight("Atltanta", "Las Vegas", "8831", 12);
            flightsArray[2].passengerArray[0] = new Passenger("Mary", "Moore", "553652");
            flightsArray[2].passengerArray[1] = new Passenger("Sharon", "Jones", "885794");
            flightsArray[2].passengerArray[2] = new Passenger("Clark", "Miller", "009395");
            flightsArray[2].passengerArray[3] = new Passenger("Jones", "White", "449388");
            flightsArray[2].passengerArray[4] = new Passenger("Donna", "Martin", "532384");
            flightsArray[2].passengerArray[5] = new Passenger("John", "Thompson", "885749");
            flightsArray[2].passengerArray[6] = new Passenger("Sandra", "Clark", "134532");
            flightsArray[2].passengerArray[7] = new Passenger("John", "Smith", "345532");
            flightsArray[2].passengerArray[8] = new Passenger("Paul", "Lewis", "633564");
            flightsArray[2].passengerArray[9] = new Passenger("Robert", "Williams", "883746");
            flightsArray[2].passengerArray[10] = new Passenger("Karen", "Robinson", "356463");
            flightsArray[2].passengerArray[11] = new Passenger("Sarah", "Smith", "987594");
            flightsArray[3] = new Flight("Los Angeles", "New York", "452", 0);
            // updating the number of flights added
            numberOfFlightsAdded = 4;
        }

        /// <summary>
        /// Creates the controls needed to add or edit a new flight or a new passenger and adjust the screen
        /// </summary>
        /// <param name="isFlight">True - if it is a flight / False - if it is a passenger</param>
        private void CreateScren_AddEditFlightOrPassenger(bool isFlight)
        {
            // adjusting the panel size and position on the screen
            informationPanel.Width = 555;
            informationPanel.Height = 100;
            informationPanel.Visible = true;
            informationPanel.Location = new Point(29, 39);
            informationPanel.BackColor = Color.White;
            informationPanel.AutoScroll = false;

            // creating and adjusting the labels 
            Label titleLabel = new Label();
            titleLabel.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold);
            titleLabel.Visible = true;
            titleLabel.Width = 555;
            titleLabel.Height = 18;
            titleLabel.Location = new Point(-2, 7);
            titleLabel.TextAlign = ContentAlignment.MiddleCenter;
            informationPanel.Controls.Add(titleLabel);
            Label numberLabel = new Label();
            numberLabel.Name = "numberLabel";
            numberLabel.Height = 14;
            numberLabel.Location = new Point(17, 43);
            numberLabel.Visible = true;
            informationPanel.Controls.Add(numberLabel);
            Label string1Label = new Label();
            string1Label.Height = 14;
            string1Label.Location = new Point(157, 43);
            string1Label.Visible = true;
            informationPanel.Controls.Add(string1Label);
            Label string2Label = new Label();
            string2Label.Height = 14;
            string2Label.Location = new Point(297, 43);
            string2Label.Visible = true;
            informationPanel.Controls.Add(string2Label);

            // creating and adjusting the textboxes
            TextBox numberTextBox = new TextBox();
            numberTextBox.Name = "numberTextBox";
            numberTextBox.Location = new Point(20, 63);
            numberTextBox.Visible = true;
            numberTextBox.Width = 134;
            numberTextBox.TabIndex = 0;
            numberTextBox.GotFocus += textBox_GotFocus;
            numberTextBox.MouseClick += textBox_GotFocus;
            informationPanel.Controls.Add(numberTextBox);
            numberTextBox.Focus();
            TextBox string1TextBox = new TextBox();
            string1TextBox.Name = "string1TextBox";
            string1TextBox.Location = new Point(160, 63);
            string1TextBox.Visible = true;
            string1TextBox.Width = 134;
            string1TextBox.TabIndex = 1;
            string1TextBox.GotFocus += textBox_GotFocus;
            string1TextBox.MouseClick += textBox_GotFocus;
            informationPanel.Controls.Add(string1TextBox);
            TextBox string2TextBox = new TextBox();
            string2TextBox.Name = "string2TextBox";
            string2TextBox.Location = new Point(300, 63);
            string2TextBox.Visible = true;
            string2TextBox.Width = 134;
            string2TextBox.TabIndex = 2;
            string2TextBox.GotFocus += textBox_GotFocus;
            string2TextBox.MouseClick += textBox_GotFocus;
            informationPanel.Controls.Add(string2TextBox);

            // creating and adjusting the button
            Button addNewButton = new Button();
            addNewButton.Location = new Point(440, 60);
            addNewButton.Visible = true;
            addNewButton.Width = 95;
            addNewButton.Text = "Add New";
            addNewButton.TabIndex = 3;
            informationPanel.Controls.Add(addNewButton);

            // if the flag isFLight is true, adjust the labels name and the button event to create the "new flight" screen
            if (isFlight)
            {
                numberLabel.Text = "Flight Number";
                string1Label.Text = "Origin";
                string2Label.Text = "Destination";

                // if selectedFlight is greater than -1 is because there is a flight selected, so the screen will be adjusted to edit this selected flight
                if (selectedFlight > -1)
                {
                    titleLabel.Text = "Edit Flight";
                    addNewButton.Click += editFlight_Click;
                    numberTextBox.Text = flightsArray[selectedFlight].FlightNumber;
                    string1TextBox.Text = flightsArray[selectedFlight].Origin;
                    string2TextBox.Text = flightsArray[selectedFlight].Destination;
                }
                // if selectedFlight is not greater than -1, there is no selected flight, so the screen will be adjusted to add a new flight
                else
                {
                    titleLabel.Text = "Add New Flight";
                    addNewButton.Click += addNewFlight_Click;
                }
            }
            // if isFlight is false, adjust the labels name and the button event to create the "new passenger" screen
            else
            {
                numberLabel.Text = "Loyalty Number";
                string1Label.Text = "First Name";
                string2Label.Text = "Last Name";
                titleLabel.Text = "Add New Passenger";
                addNewButton.Click += addNewPassenger_Click;
            }
        }

        /// <summary>
        /// Creates the controls needed to display the list of flights or passengers manifest and adjust the screen
        /// </summary>
        /// <param name="isFlight">True - if it is a flight / False - if it is a passenger</param>
        /// <param name="isSelect">True - if it is the select screen / False - if it is the display screen
        private void CreateScreen_DisplayFlightsOrPassengersList(bool isFlight, bool isSelect = false)
        {
            // starts the height of the controls as a begining position so it can be incremented to create a ordered list
            int listHeight = 47;

            // adjusting the panel size and position on the screen
            informationPanel.Width = 590;
            informationPanel.Height = 310;
            informationPanel.Visible = true;
            informationPanel.Location = new Point(12, 39);
            informationPanel.BackColor = Color.White;
            informationPanel.AutoScroll = true;

            // creating and adjusting the title labels
            Label titleLabel = new Label();
            titleLabel.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold);
            titleLabel.Visible = true;
            titleLabel.Width = 590;
            titleLabel.Height = 18;
            titleLabel.Location = new Point(-2, 7);
            titleLabel.TextAlign = ContentAlignment.MiddleCenter;
            informationPanel.Controls.Add(titleLabel);
            Label column1Label = new Label();
            column1Label.Font = new Font("Microsoft Sans Serif", 8, FontStyle.Bold);
            column1Label.Height = 14;
            column1Label.Visible = true;
            informationPanel.Controls.Add(column1Label);
            Label column2Label = new Label();
            column2Label.Font = new Font("Microsoft Sans Serif", 8, FontStyle.Bold);
            column2Label.Height = 14;
            column2Label.Visible = true;
            informationPanel.Controls.Add(column2Label);
            Label column3Label = new Label();
            column3Label.Font = new Font("Microsoft Sans Serif", 8, FontStyle.Bold);
            column3Label.Height = 14;
            column3Label.Visible = true;
            informationPanel.Controls.Add(column3Label);
            
            // if isFlight is true, adjust the screen to show a list of flights number, origin and destination
            if (isFlight)
            {
                // adjusting labels text and position
                column1Label.Location = new Point(96, listHeight);
                column1Label.Text = "Flight Number";
                column2Label.Location = new Point(230, listHeight);
                column2Label.Text = "Origin";
                column3Label.Location = new Point(421, listHeight);
                column3Label.Text = "Destination";

                if (isSelect)
                    titleLabel.Text = "Select a Flight";
                else
                    titleLabel.Text = "Flights List";

                // incrementing the height to show the list right below the title labels
                listHeight += 30;

                // scroll through the array of flights
                for (int i = 0; i < numberOfFlightsAdded; i++)
                {
                    // if isSelect is true, create a radioButton to each flight so it can be selected
                    if (isSelect)
                    {
                        RadioButton radioButton = new RadioButton();
                        radioButton.Width = 14;
                        radioButton.Height = 14;
                        radioButton.TextAlign = ContentAlignment.MiddleCenter;
                        radioButton.Location = new Point(76, listHeight);
                        radioButton.Visible = true;
                        radioButton.Tag = i;
                        radioButton.CheckedChanged += radioButton_CheckedChanged;
                        informationPanel.Controls.Add(radioButton);
                    }
                    // if isSelect is false, create a label of position to each flight
                    else
                    {
                        Label positionLabel = new Label();
                        positionLabel.Font = new Font("Microsoft Sans Serif", 8, FontStyle.Bold);
                        positionLabel.Height = 14;
                        positionLabel.Width = 28;
                        positionLabel.Location = new Point(58, listHeight);
                        positionLabel.Visible = true;
                        positionLabel.Text = (i + 1).ToString() + ".";
                        informationPanel.Controls.Add(positionLabel);
                    }

                    // creating and adjusting the labels to show the information about this flight
                    Label flyNum = new Label();
                    flyNum.Height = 14;
                    flyNum.Location = new Point(96, listHeight);
                    flyNum.Visible = true;
                    flyNum.Text = flightsArray[i].FlightNumber;
                    informationPanel.Controls.Add(flyNum);
                    Label origin = new Label();
                    origin.Height = 14;
                    origin.Location = new Point(230, listHeight);
                    origin.Visible = true;
                    origin.Text = flightsArray[i].Origin;
                    informationPanel.Controls.Add(origin);
                    Label arrow = new Label();
                    arrow.Height = 14;
                    arrow.Location = new Point(319, listHeight);
                    arrow.Visible = true;
                    arrow.Text = "--------------->";
                    informationPanel.Controls.Add(arrow);
                    Label destination = new Label();
                    destination.Height = 14;
                    destination.Location = new Point(421, listHeight);
                    destination.Visible = true;
                    destination.Text = flightsArray[i].Destination;
                    informationPanel.Controls.Add(destination);

                    // incrementing the height to show the next information right below it
                    listHeight += 20;
                }
            }
            // if isFlight is false, adjust the screen to show a list of passengers loyalty number, first name, last name and TSA flag
            else
            {
                // adjustng labels text and position
                titleLabel.Text = "Passengers Manifest";
                column1Label.Location = new Point(55, listHeight);
                column1Label.Text = "First Name";
                column2Label.Location = new Point(163, listHeight);
                column2Label.Text = "Last Name";
                column3Label.Location = new Point(299, listHeight);
                column3Label.Text = "Loyalty Number";

                // creating a new column to show the TSA flag
                Label column4Label = new Label();
                column4Label.Font = new Font("Microsoft Sans Serif", 8, FontStyle.Bold);
                column4Label.Height = 14;
                column4Label.Width = 80;
                column4Label.Visible = true;
                column4Label.Location = new Point(420, listHeight);
                column4Label.Text = "Flagged";
                informationPanel.Controls.Add(column4Label);

                // creating a new column to show the button to delete passenger
                Label column5Label = new Label();
                column5Label.Font = new Font("Microsoft Sans Serif", 8, FontStyle.Bold);
                column5Label.Height = 14;
                column5Label.Width = 45;
                column5Label.Visible = true;
                column5Label.Location = new Point(510, listHeight);
                column5Label.Text = "Delete";
                informationPanel.Controls.Add(column5Label);

                // incrementing the height to show the list right below the title labels
                listHeight += 30;

                // scroll through the array of passengers
                for (int i = 0; i < flightsArray[selectedFlight].NumberOfPassengers; i++)
                {
                    // creating a label of position to each flight
                    Label positionLabel = new Label();
                    positionLabel.Font = new Font("Microsoft Sans Serif", 8, FontStyle.Bold);
                    positionLabel.Height = 14;
                    positionLabel.Width = 28;
                    positionLabel.Location = new Point(17, listHeight);
                    positionLabel.Visible = true;
                    positionLabel.Text = (i + 1).ToString() + ".";
                    informationPanel.Controls.Add(positionLabel);

                    // creating and adjusting the labels to show the information about this passenger
                    Label firstNameLabel = new Label();
                    firstNameLabel.Height = 14;
                    firstNameLabel.Location = new Point(55, listHeight);
                    firstNameLabel.Visible = true;
                    firstNameLabel.Text = flightsArray[selectedFlight].passengerArray[i].FirstName;
                    informationPanel.Controls.Add(firstNameLabel);
                    Label lastNameLabel = new Label();
                    lastNameLabel.Height = 14;
                    lastNameLabel.Location = new Point(163, listHeight);
                    lastNameLabel.Visible = true;
                    lastNameLabel.Text = flightsArray[selectedFlight].passengerArray[i].LastName;
                    informationPanel.Controls.Add(lastNameLabel);
                    Label loyaltyNumberLabel = new Label();
                    loyaltyNumberLabel.Height = 14;
                    loyaltyNumberLabel.Location = new Point(299, listHeight);
                    loyaltyNumberLabel.Visible = true;
                    loyaltyNumberLabel.Text = flightsArray[selectedFlight].passengerArray[i].LoyaltyNumber;
                    informationPanel.Controls.Add(loyaltyNumberLabel);
                    Label flaggedLabel = new Label();
                    flaggedLabel.Height = 14;
                    flaggedLabel.ForeColor = Color.Red;
                    flaggedLabel.Location = new Point(420, listHeight);
                    flaggedLabel.Visible = true;
                    if (flightsArray[selectedFlight].passengerArray[i].SecurityFlag)
                        flaggedLabel.Text = "!!!";
                    else
                        flaggedLabel.Text = "";
                    informationPanel.Controls.Add(flaggedLabel);
                    Button deleteButton = new Button();
                    deleteButton.Text = "X";
                    deleteButton.Font = new Font("Microsoft Sans Serif", 5, FontStyle.Bold);
                    deleteButton.ForeColor = Color.Red;
                    deleteButton.TextAlign = ContentAlignment.BottomCenter;
                    deleteButton.Height = 14;
                    deleteButton.Width = 14;
                    deleteButton.Visible = true;
                    deleteButton.Location = new Point(525, listHeight);
                    deleteButton.Tag = i.ToString();
                    deleteButton.Click += deleteButton_Click;
                    informationPanel.Controls.Add(deleteButton);

                    // incrementing the height to show the next information right below it
                    listHeight += 20;
                }
            }
        }

        /// <summary>
        /// Creates the controls needed to search a flight by passenger first and last name and adjust the screen
        /// </summary>
        private void CreateScreen_SearchByPassenger()
        {
            // adjusting the panel size and position on the screen
            informationPanel.Width = 590;
            informationPanel.Height = 310;
            informationPanel.Visible = true;
            informationPanel.Location = new Point(12, 39);
            informationPanel.BackColor = Color.White;
            informationPanel.AutoScroll = true;
            resultPanel.Visible = true;

            // creating and adjusting the title labels
            Label titleLabel = new Label();
            titleLabel.Font = new Font("Microsoft Sans Serif", 10, FontStyle.Bold);
            titleLabel.Visible = true;
            titleLabel.Width = 590;
            titleLabel.Height = 18;
            titleLabel.Location = new Point(-2, 7);
            titleLabel.TextAlign = ContentAlignment.MiddleCenter;
            titleLabel.Text = "Search by Passenger";
            titleLabel.Name = "titleLabel";
            informationPanel.Controls.Add(titleLabel);
            Label firstNLabel = new Label();
            firstNLabel.Height = 14;
            firstNLabel.Location = new Point(107, 47);
            firstNLabel.Visible = true;
            firstNLabel.Text = "First Name";
            firstNLabel.Name = "firstNLabel";
            informationPanel.Controls.Add(firstNLabel);
            Label lastNLabel = new Label();
            lastNLabel.Height = 14;
            lastNLabel.Location = new Point(259, 47);
            lastNLabel.Visible = true;
            lastNLabel.Text = "Last Name";
            lastNLabel.Name = "lastNLabel";
            informationPanel.Controls.Add(lastNLabel);

            // creating and adjusting the textboxes
            TextBox fNameTextBox = new TextBox();
            fNameTextBox.Name = "fNameTextBox";
            fNameTextBox.Location = new Point(110, 63);
            fNameTextBox.Visible = true;
            fNameTextBox.Width = 134;
            fNameTextBox.TabIndex = 0;
            fNameTextBox.GotFocus += textBox_GotFocus;
            fNameTextBox.MouseClick += textBox_GotFocus;
            informationPanel.Controls.Add(fNameTextBox);
            fNameTextBox.Focus();
            TextBox lNameTextBox = new TextBox();
            lNameTextBox.Name = "lNameTextBox";
            lNameTextBox.Location = new Point(262, 63);
            lNameTextBox.Visible = true;
            lNameTextBox.Width = 134;
            lNameTextBox.TabIndex = 1;
            lNameTextBox.GotFocus += textBox_GotFocus;
            lNameTextBox.MouseClick += textBox_GotFocus;
            informationPanel.Controls.Add(lNameTextBox);

            // creating and adjusting the button
            Button searchButton = new Button();
            searchButton.Location = new Point(414, 60);
            searchButton.Visible = true;
            searchButton.Width = 75;
            searchButton.Text = "Search";
            searchButton.Click += searchButton_Click;
            searchButton.TabIndex = 2;
            informationPanel.Controls.Add(searchButton);
        }

        /// <summary>
        /// Validates the information before add a new passenger or add or edit flight
        /// </summary>
        /// <param name="str1">The value of one of the textbox that should contains a string - Passed by reference</param>
        /// <param name="str2">The value of one of the textbox that should contains a string - Passed by reference</param>
        /// <param name="number">The value of one of the textbox that should contains a number - Passed by reference</param>
        /// <returns>True - when the values are valid / False - when the values are invalid</returns>
        private bool ValidateInformation(ref string str1, ref string str2, ref string number)
        {
            try
            {
                // gets the text values of the string textboxes
                str1 = ((TextBox)informationPanel.Controls["string1TextBox"]).Text;
                str2 = ((TextBox)informationPanel.Controls["string2TextBox"]).Text;
                // gets the textbox control of the textbox that should have a number
                // (it is ever the first textbox of the screen, so we need the control to set focus on it if the values are invalid)
                TextBox numberTB = (TextBox)informationPanel.Controls["numberTextBox"];
                number = numberTB.Text;
                // gets the label of the number textbox (to show on the error message if needed)
                string labelTitle = ((Label)informationPanel.Controls["numberLabel"]).Text;
                int result;

                // if any textbox is empty, show an error message and return false
                if (str1 == "" || str2 == "" || number == "")
                {
                    MessageBox.Show("All fields are needed. Fill all!");
                    numberTB.Focus();
                    return false;
                }

                // if the number textbox is not a number, show an error message and return false
                if (!Int32.TryParse(number, out result))
                {
                    MessageBox.Show(labelTitle.ToString() + " must be numeric!");
                    numberTB.Focus();
                    return false;
                }

                return true;
            }
            catch (Exception)
            {
                CatchException();
                return false;
            }
        }

        /// <summary>
        /// Show an error message and reset the screen to the initial state
        /// </summary>
        private void CatchException()
        {
            MessageBox.Show("An error occured. Try again later!");
            ResetScreen();
        }

        /// <summary>
        /// Search the flight number by passenger first and last name
        /// </summary>
        /// <param name="firstName">The first name of the passenger</param>
        /// <param name="lastName">The last name of the passenger</param>
        private void SearchByPassenger(string firstName, string lastName)
        {
            // clean the older result, if there is any
            resultPanel.Controls.Clear();

            // bool that controls if it found a flight or not
            bool found = false;
            // starts the height of the controls as a begining position so it can be incremented to create a ordered list
            int listHeight = 35;

            // scroll through the array of flights
            for (int i = 0; i < numberOfFlightsAdded; i++)
            {
                // scroll through the array of passengers
                for (int j = 0; j < flightsArray[i].NumberOfPassengers; j++)
                {
                    // if there is a passenger with the searched first and last names, 
                    // it shows on the list the number of the flight and the name and loyalty number of the passenger
                    if (flightsArray[i].passengerArray[j].FirstName == firstName &&
                        flightsArray[i].passengerArray[j].LastName == lastName)
                    {
                        found = true;

                        Label flyNumLabel = new Label();
                        flyNumLabel.Height = 14;
                        flyNumLabel.Location = new Point(68, listHeight);
                        flyNumLabel.Visible = true;
                        flyNumLabel.Text = flightsArray[i].FlightNumber;
                        resultPanel.Controls.Add(flyNumLabel);
                        Label fNameLabel = new Label();
                        fNameLabel.Height = 14;
                        fNameLabel.Location = new Point(184, listHeight);
                        fNameLabel.Visible = true;
                        fNameLabel.Text = flightsArray[i].passengerArray[j].FirstName;
                        resultPanel.Controls.Add(fNameLabel);
                        Label lNameLabel = new Label();
                        lNameLabel.Height = 14;
                        lNameLabel.Location = new Point(292, listHeight);
                        lNameLabel.Visible = true;
                        lNameLabel.Text = flightsArray[i].passengerArray[j].LastName;
                        resultPanel.Controls.Add(lNameLabel);
                        Label loyNumLabel = new Label();
                        loyNumLabel.Height = 14;
                        loyNumLabel.Location = new Point(428, listHeight);
                        loyNumLabel.Visible = true;
                        loyNumLabel.Text = flightsArray[i].passengerArray[j].LoyaltyNumber;
                        resultPanel.Controls.Add(loyNumLabel);

                        // incrementing the height to show the list right below the title labels
                        listHeight += 20;
                    }
                }
            }

            // seting the height to show the title labels right above the list
            listHeight = 5;

            // if found is true, show the title labels
            if (found)
            {
                Label flightNumberLabel = new Label();
                flightNumberLabel.Font = new Font("Microsoft Sans Serif", 8, FontStyle.Bold);
                flightNumberLabel.Height = 14;
                flightNumberLabel.Location = new Point(68, listHeight);
                flightNumberLabel.Visible = true;
                flightNumberLabel.Text = "Flight Number";
                resultPanel.Controls.Add(flightNumberLabel);
                Label firstNameLabel = new Label();
                firstNameLabel.Font = new Font("Microsoft Sans Serif", 8, FontStyle.Bold);
                firstNameLabel.Height = 14;
                firstNameLabel.Location = new Point(184, listHeight);
                firstNameLabel.Visible = true;
                firstNameLabel.Text = "First Name";
                resultPanel.Controls.Add(firstNameLabel);
                Label lastNameLabel = new Label();
                lastNameLabel.Font = new Font("Microsoft Sans Serif", 8, FontStyle.Bold);
                lastNameLabel.Height = 14;
                lastNameLabel.Location = new Point(292, listHeight);
                lastNameLabel.Visible = true;
                lastNameLabel.Text = "Last Name";
                resultPanel.Controls.Add(lastNameLabel);
                Label loyaltyNumberLabel = new Label();
                loyaltyNumberLabel.Font = new Font("Microsoft Sans Serif", 8, FontStyle.Bold);
                loyaltyNumberLabel.Height = 14;
                loyaltyNumberLabel.Location = new Point(428, listHeight);
                loyaltyNumberLabel.Visible = true;
                loyaltyNumberLabel.Text = "Loyalty Number";
                resultPanel.Controls.Add(loyaltyNumberLabel);
            }
            else
            {
                MessageBox.Show("No passenger found!");
            }
        }

        /// <summary>
        /// Run the TSA (Transportion Security Administration) security check
        /// </summary>
        /// <returns>True - when it runs with success / False - if it have some error</returns>
        private bool RunSecurityCheck()
        {
            try
            {
                // reseting the security flagg of the passengers manifest
                for (int i = 0; i < flightsArray[selectedFlight].NumberOfPassengers; i++)
                    flightsArray[selectedFlight].passengerArray[i].SecurityFlag = false;

                // run the TSA to generate the list of flagged passengers
                TSA tsa = new TSA();
                Passenger[] flaggedPassengers =
                    tsa.RunSecurityCheck(flightsArray[selectedFlight].passengerArray, flightsArray[selectedFlight].NumberOfPassengers);

                // scroll trought the array of passengers
                for (int i = 0; i < flightsArray[selectedFlight].NumberOfPassengers; i++)
                {
                    // scroll trought the array of flagged passengers
                    for (int j = 0; j < flaggedPassengers.Length; j++)
                    {
                        // if the passenger have the same first name, last name and loyalty number as the flagged passenger, sets the security flag true
                        if (flightsArray[selectedFlight].passengerArray[i].FirstName == flaggedPassengers[j].FirstName &&
                            flightsArray[selectedFlight].passengerArray[i].LastName == flaggedPassengers[j].LastName &&
                            flightsArray[selectedFlight].passengerArray[i].LoyaltyNumber == flaggedPassengers[j].LoyaltyNumber)
                            flightsArray[selectedFlight].passengerArray[i].SecurityFlag = true;

                    }
                }
                MessageBox.Show("Security check ran with success!");
                return true;
            }
            catch (Exception)
            {
                CatchException();
                return false;
            }
        }

        /// <summary>
        /// Update the name of the form according with the actual screen
        /// </summary>
        private void UpdateFormName()
        {
            // if selectedFlight is grather than -1, there is a selected flight, so it shows information about this flight on the form name
            if (selectedFlight > -1)
                this.Text = "CHARMS - Flight " + flightsArray[selectedFlight].FlightNumber + " (" +
                    flightsArray[selectedFlight].Origin + " -> " + flightsArray[selectedFlight].Destination + ")";
            // if selectedFlight is -1, show the system name
            else
                this.Text = "CHARMS";
        }

        /// <summary>
        /// Reset the screen to the initial state
        /// </summary>
        private void ResetScreen()
        {
            informationPanel.Controls.Clear();
            informationPanel.Visible = false;
            resultPanel.Controls.Clear();
            resultPanel.Visible = false;
            UpdateFormName();
        }

        /// <summary>
        /// Clear all textboxes
        /// </summary>
        private void ClearTextBoxes()
        {
            try
            {
                // reset the text to the default state
                informationPanel.Controls["string1TextBox"].ResetText();
                informationPanel.Controls["string2TextBox"].ResetText();
                informationPanel.Controls["numberTextBox"].ResetText();
                // set focus on the number textbox
                informationPanel.Controls["numberTextBox"].Focus();
            }
            catch (Exception)
            {
                CatchException();
            }
        }

        /// <summary>
        /// Exit the second menu and return to the first one
        /// </summary>
        private void ExitSecondMenu()
        {
            selectedFlight = -1;

            menuToolStripMenuItem1.Visible = true;
            menuToolStripMenuItem2.Visible = false;
            exitToolStripMenuItem.Visible = true;
            exitToCHARMSToolStripMenuItem.Visible = false;
            ResetScreen();
        }

        /// <summary>
        /// Exit the second menu and return to the first one
        /// </summary>
        private void DeletePassenger(int passengerIndex)
        {
            // decrease the number of passengers of this flight
            flightsArray[selectedFlight].NumberOfPassengers--;

            // scroll through the passengers list, starting on the one that will be deleted, and replace this for the next one on the list 
            for (int i = passengerIndex; i < flightsArray[selectedFlight].NumberOfPassengers; i++)
            {
                flightsArray[selectedFlight].passengerArray[i] = flightsArray[selectedFlight].passengerArray[i + 1];
            }

            // set the last element null
            flightsArray[selectedFlight].passengerArray[flightsArray[selectedFlight].NumberOfPassengers + 1] = null;
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                // gets the index of the passenger that the user wants to delete
                int passengerIndex = Convert.ToInt32(((Button)sender).Tag);
                string passengerFullName = flightsArray[selectedFlight].passengerArray[passengerIndex].FirstName 
                    + " " + flightsArray[selectedFlight].passengerArray[passengerIndex].LastName;

                // verifies if the user really wants to delete this passenger
                if (MessageBox.Show("Are you sure you want to delete " + passengerFullName + " from the passengers manifest?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    // delete the passenger, reset the screen and show the new passengers manifest
                    DeletePassenger(passengerIndex);
                    MessageBox.Show(passengerFullName + " has been deleted from the passengers manifest with success!");
                    ResetScreen();
                    CreateScreen_DisplayFlightsOrPassengersList(false);
                }
            }
            catch (Exception)
            {
                CatchException();
            }
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            try
            {
                // gets the string of the textbox
                string firstName = ((TextBox)informationPanel.Controls["fNameTextBox"]).Text;
                string lastName = ((TextBox)informationPanel.Controls["lNameTextBox"]).Text;

                SearchByPassenger(firstName, lastName);
            }
            catch (Exception)
            {
                CatchException();
            }
        }

        private void editFlight_Click(object sender, EventArgs e)
        {
            try
            {
                // creating the variables to receive the value of the textbox
                string origin = "";
                string destination = "";
                string flightNumber = "";

                // validate information and getting the values by reference
                if (ValidateInformation(ref origin, ref destination, ref flightNumber))
                {
                    // editing the information of the selected flight
                    Flight flight = flightsArray[selectedFlight];
                    flight.FlightNumber = flightNumber;
                    flight.Origin = origin;
                    flight.Destination = destination;
                    MessageBox.Show("Flight edited with success!");
                    ResetScreen();
                }
            }
            catch (Exception)
            {
                CatchException();
            }
        }

        private void addNewFlight_Click(object sender, EventArgs e)
        {
            try
            {
                // creating the variables to receive the value of the textbox
                string origin = "";
                string destination = "";
                string flightNumber = "";

                // validate information and getting the values by reference
                if (ValidateInformation(ref origin, ref destination, ref flightNumber))
                {
                    // creating a new flight
                    Flight newFlight = new Flight(origin, destination, flightNumber);
                    // adding the new flight to the array of flights
                    flightsArray[numberOfFlightsAdded] = newFlight;
                    // incrementing the counter of flights added
                    numberOfFlightsAdded++;
                    MessageBox.Show("New flight added with success!");

                    // verifing if the user want to add another flight
                    if (MessageBox.Show("You want to add more flights?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.No)
                        ResetScreen(); // reset the screen if the user dont want to add another flight
                    else
                        ClearTextBoxes(); // clear all textbox if the user want to add another flight
                }
            }
            catch (Exception)
            {
                CatchException();
            }
        }

        private void addNewPassenger_Click(object sender, EventArgs e)
        {
            try
            {
                // creating the variables to receive the value of the textbox
                string firstName = "";
                string lastName = "";
                string loyaltyNumber = "";

                // validate information and getting the values by reference
                if (ValidateInformation(ref firstName, ref lastName, ref loyaltyNumber))
                {
                    // creating a new passenger
                    Passenger newPassenger = new Passenger(firstName, lastName, loyaltyNumber);
                    // adding the new passenger into the array of passenger of the selected flight
                    flightsArray[selectedFlight].passengerArray[flightsArray[selectedFlight].NumberOfPassengers] = newPassenger;
                    // incrementing the counter of number of passengers
                    flightsArray[selectedFlight].NumberOfPassengers++;
                    MessageBox.Show("New passenger added with success to the flight " + flightsArray[selectedFlight].FlightNumber.ToString() + "!");

                    // verifing if the user want to add another passenger
                    if (MessageBox.Show("You want to add more passengers?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.No)
                        ResetScreen(); // reset the screen if the user dont want to add another passenger
                    else
                        ClearTextBoxes(); // clear all textbox if the user want to add another passenger
                }
            }
            catch (Exception)
            {
                CatchException();
            }
        }

        private void addNewFlightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetScreen();
            // if the number of flights added is grather than 29, so the array of flights is full
            if (numberOfFlightsAdded > 29)
                MessageBox.Show("You already have added 30 flights and you can't add more than that!");
            // if the array of flights is not full, add another flight
            else
                CreateScren_AddEditFlightOrPassenger(true); // creating the screen to add a new flight
        }

        private void addNewPassengerToManifestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetScreen();
            // if selectedFlight is grather than -1, there is a selected flight, continue
            if (selectedFlight > -1)
            {
                // if the number of passengers on the flight is grather than 99, so this flight is full
                if (flightsArray[selectedFlight].NumberOfPassengers > 99)
                    MessageBox.Show("This flight already have 100 passengers, it is full!");
                // if the flight is not full, add a new passenger
                else
                    CreateScren_AddEditFlightOrPassenger(false); // creating the screen to add a new passenger 
            }
            // if selectedFlight is -1, there is not a selected flight, get back to the first menu
            else
                ExitSecondMenu();
        }

        private void displayFlightsListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetScreen();
            // if the number of flights added is 0, there is no flights added
            if (numberOfFlightsAdded == 0)
                MessageBox.Show("There is no flights added!");
            // if there is any flights added, show the list
            else
                CreateScreen_DisplayFlightsOrPassengersList(true); // creating the screen to show the list of flights added
        }

        private void selectFlightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetScreen();
            // if the number of flights added is 0, there is no flights added
            if (numberOfFlightsAdded == 0)
                MessageBox.Show("There is no flights added!");
            // if there is any flights added, show the list
            else
                // creating the screen to show the list of flights added with the radioButton to select one flight
                CreateScreen_DisplayFlightsOrPassengersList(true, true); 
        }

        private void searchByPassengerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetScreen();
            CreateScreen_SearchByPassenger();
        }

        private void exitToCHARMSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExitSecondMenu();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void radioButton_CheckedChanged(object sender, EventArgs e)
        {
            // read the tag of the selected radioButton (the tag contains the index of the selected flight)
            selectedFlight = Convert.ToInt32(((RadioButton)sender).Tag);

            // hide the first menu and show the second one
            menuToolStripMenuItem1.Visible = false;
            menuToolStripMenuItem2.Visible = true;
            exitToolStripMenuItem.Visible = false;
            exitToCHARMSToolStripMenuItem.Visible = true;
            ResetScreen();
        }

        private void textBox_GotFocus(object sender, EventArgs e)
        {
            // select all from the textbox when it gets focus
            ((TextBox)sender).SelectAll();
        }

        private void CHARMS_FormClosing(object sender, FormClosingEventArgs e)
        {
            // verifies if the user really want to close the system
            if (MessageBox.Show("Are you sure you want to leave CHARMS?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.No)
                e.Cancel = true;
        }

        private void editFlightInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetScreen();
            // if the number of flights added is grather than 0 and there is a selected flight, create the screen to edit this flight information
            if (numberOfFlightsAdded > 0 && selectedFlight > -1)
                CreateScren_AddEditFlightOrPassenger(true);
            // if the number of flights added is 0 or there is not a selected flight, go back to the first menu
            else
                ExitSecondMenu();
        }

        private void displayPassengerManifestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetScreen();
            // if selectedFlight is grather than -1, there is a selected flight, continue
            if (selectedFlight > -1)
            {
                // if the number of passengers on the flight is 0, so there is no passengers on this flight
                if (flightsArray[selectedFlight].NumberOfPassengers == 0)
                    MessageBox.Show("There is no passengers on this flight yet!");
                // if the number of passengers on the flight is grather than 0, show the list of passengers
                else
                    CreateScreen_DisplayFlightsOrPassengersList(false);
            }
            // if selectedFlight is -1, there is not a selected flight, get back to the first menu
            else
                ExitSecondMenu();
        }

        private void runPassengerSecurityCheckToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetScreen();
            // if selectedFlight is grather than -1, there is a selected flight, continue
            if (selectedFlight > -1)
            {
                // if the number of passengers on the flight is 0, so there is no passengers on this flight
                if (flightsArray[selectedFlight].NumberOfPassengers == 0)
                    MessageBox.Show("There is no passengers on this flight yet!");
                // if the number of passengers on the flight is grather than 0, run the security check for this passengers
                else
                {
                    if (RunSecurityCheck())
                        CreateScreen_DisplayFlightsOrPassengersList(false); // show the list of passengers before run the security check
                }
            }
            // if selectedFlight is -1, there is not a selected flight, get back to the first menu
            else
                ExitSecondMenu();
        }

        private void displayFlightInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetScreen();
            // if selectedFlight is grather than -1, there is a selected flight, continue
            if (selectedFlight > -1)
            {
                // show a message with the flight informations
                MessageBox.Show(flightsArray[selectedFlight].FlightNumber + " (" + flightsArray[selectedFlight].Origin + " -> " + flightsArray[selectedFlight].Destination
                    + ")\nNumber of Passengers at the Manifest: " + flightsArray[selectedFlight].NumberOfPassengers);
            }
            // if selectedFlight is -1, there is not a selected flight, get back to the first menu
            else
                ExitSecondMenu();
        }
    }
}
