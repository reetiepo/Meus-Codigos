﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HomelandSecurity;

namespace CHARMS
{
    class Flight
    {
        // Project, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        // Variables that defines caracteristics of a flight
        public string Origin { get; set; }
        public string Destination { get; set; }
        public string FlightNumber { get; set; }
        public Passenger[] passengerArray { get; set; }
        public int NumberOfPassengers;

        /// <summary>
        /// Creates a new flight
        /// </summary>
        /// <param name="origin">The origin of the flight</param>
        /// <param name="destination">The destination of the flight</param>
        /// <param name="flightNumber">The flight number</param>
        /// <param name="numberOfPassagengers">The number of passengers - Optional</param>
        public Flight(string origin, string destination, string flightNumber, int numberOfPassagengers = 0)
        {
            Origin = origin;
            Destination = destination;
            FlightNumber = flightNumber;
            passengerArray = new Passenger[100];
            NumberOfPassengers = numberOfPassagengers;
        }
    }
}
