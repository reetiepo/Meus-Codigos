﻿namespace CHARMS
{
    partial class CHARMS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CHARMS));
            this.menuMenuStrip = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.displayFlightsListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewFlightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selectFlightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchByPassengerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.displayPassengerManifestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editFlightInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewPassengerToManifestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runPassengerSecurityCheckToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToCHARMSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.informationPanel = new System.Windows.Forms.Panel();
            this.resultPanel = new System.Windows.Forms.Panel();
            this.displayFlightInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuMenuStrip
            // 
            this.menuMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem1,
            this.exitToolStripMenuItem,
            this.menuToolStripMenuItem2,
            this.exitToCHARMSToolStripMenuItem});
            this.menuMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuMenuStrip.Name = "menuMenuStrip";
            this.menuMenuStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuMenuStrip.Size = new System.Drawing.Size(614, 24);
            this.menuMenuStrip.TabIndex = 0;
            this.menuMenuStrip.Text = "menuStrip";
            // 
            // menuToolStripMenuItem1
            // 
            this.menuToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.displayFlightsListToolStripMenuItem,
            this.addNewFlightToolStripMenuItem,
            this.selectFlightToolStripMenuItem,
            this.searchByPassengerToolStripMenuItem});
            this.menuToolStripMenuItem1.Name = "menuToolStripMenuItem1";
            this.menuToolStripMenuItem1.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem1.Text = "Menu";
            // 
            // displayFlightsListToolStripMenuItem
            // 
            this.displayFlightsListToolStripMenuItem.Name = "displayFlightsListToolStripMenuItem";
            this.displayFlightsListToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.displayFlightsListToolStripMenuItem.Text = "Display Flights List";
            this.displayFlightsListToolStripMenuItem.Click += new System.EventHandler(this.displayFlightsListToolStripMenuItem_Click);
            // 
            // addNewFlightToolStripMenuItem
            // 
            this.addNewFlightToolStripMenuItem.Name = "addNewFlightToolStripMenuItem";
            this.addNewFlightToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.addNewFlightToolStripMenuItem.Text = "Add New Flight";
            this.addNewFlightToolStripMenuItem.Click += new System.EventHandler(this.addNewFlightToolStripMenuItem_Click);
            // 
            // selectFlightToolStripMenuItem
            // 
            this.selectFlightToolStripMenuItem.Name = "selectFlightToolStripMenuItem";
            this.selectFlightToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.selectFlightToolStripMenuItem.Text = "Select Flight";
            this.selectFlightToolStripMenuItem.Click += new System.EventHandler(this.selectFlightToolStripMenuItem_Click);
            // 
            // searchByPassengerToolStripMenuItem
            // 
            this.searchByPassengerToolStripMenuItem.Name = "searchByPassengerToolStripMenuItem";
            this.searchByPassengerToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.searchByPassengerToolStripMenuItem.Text = "Search by Passenger";
            this.searchByPassengerToolStripMenuItem.Click += new System.EventHandler(this.searchByPassengerToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // menuToolStripMenuItem2
            // 
            this.menuToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.displayFlightInformationToolStripMenuItem,
            this.displayPassengerManifestToolStripMenuItem,
            this.editFlightInformationToolStripMenuItem,
            this.addNewPassengerToManifestToolStripMenuItem,
            this.runPassengerSecurityCheckToolStripMenuItem});
            this.menuToolStripMenuItem2.Name = "menuToolStripMenuItem2";
            this.menuToolStripMenuItem2.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem2.Text = "Menu";
            // 
            // displayPassengerManifestToolStripMenuItem
            // 
            this.displayPassengerManifestToolStripMenuItem.Name = "displayPassengerManifestToolStripMenuItem";
            this.displayPassengerManifestToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.displayPassengerManifestToolStripMenuItem.Text = "Display Passenger Manifest";
            this.displayPassengerManifestToolStripMenuItem.Click += new System.EventHandler(this.displayPassengerManifestToolStripMenuItem_Click);
            // 
            // editFlightInformationToolStripMenuItem
            // 
            this.editFlightInformationToolStripMenuItem.Name = "editFlightInformationToolStripMenuItem";
            this.editFlightInformationToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.editFlightInformationToolStripMenuItem.Text = "Edit Flight Information";
            this.editFlightInformationToolStripMenuItem.Click += new System.EventHandler(this.editFlightInformationToolStripMenuItem_Click);
            // 
            // addNewPassengerToManifestToolStripMenuItem
            // 
            this.addNewPassengerToManifestToolStripMenuItem.Name = "addNewPassengerToManifestToolStripMenuItem";
            this.addNewPassengerToManifestToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.addNewPassengerToManifestToolStripMenuItem.Text = "Add New Passenger to Manifest";
            this.addNewPassengerToManifestToolStripMenuItem.Click += new System.EventHandler(this.addNewPassengerToManifestToolStripMenuItem_Click);
            // 
            // runPassengerSecurityCheckToolStripMenuItem
            // 
            this.runPassengerSecurityCheckToolStripMenuItem.Name = "runPassengerSecurityCheckToolStripMenuItem";
            this.runPassengerSecurityCheckToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.runPassengerSecurityCheckToolStripMenuItem.Text = "Run Passenger Security Check";
            this.runPassengerSecurityCheckToolStripMenuItem.Click += new System.EventHandler(this.runPassengerSecurityCheckToolStripMenuItem_Click);
            // 
            // exitToCHARMSToolStripMenuItem
            // 
            this.exitToCHARMSToolStripMenuItem.Name = "exitToCHARMSToolStripMenuItem";
            this.exitToCHARMSToolStripMenuItem.Size = new System.Drawing.Size(103, 20);
            this.exitToCHARMSToolStripMenuItem.Text = "Exit to CHARMS";
            this.exitToCHARMSToolStripMenuItem.Click += new System.EventHandler(this.exitToCHARMSToolStripMenuItem_Click);
            // 
            // informationPanel
            // 
            this.informationPanel.AutoScroll = true;
            this.informationPanel.BackColor = System.Drawing.Color.White;
            this.informationPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.informationPanel.Location = new System.Drawing.Point(12, 39);
            this.informationPanel.Name = "informationPanel";
            this.informationPanel.Size = new System.Drawing.Size(590, 310);
            this.informationPanel.TabIndex = 1;
            // 
            // resultPanel
            // 
            this.resultPanel.AutoScroll = true;
            this.resultPanel.BackColor = System.Drawing.Color.White;
            this.resultPanel.Location = new System.Drawing.Point(17, 148);
            this.resultPanel.Name = "resultPanel";
            this.resultPanel.Size = new System.Drawing.Size(580, 200);
            this.resultPanel.TabIndex = 2;
            // 
            // displayFlightInformationToolStripMenuItem
            // 
            this.displayFlightInformationToolStripMenuItem.Name = "displayFlightInformationToolStripMenuItem";
            this.displayFlightInformationToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.displayFlightInformationToolStripMenuItem.Text = "Display Flight Information";
            this.displayFlightInformationToolStripMenuItem.Click += new System.EventHandler(this.displayFlightInformationToolStripMenuItem_Click);
            // 
            // CHARMS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(614, 361);
            this.Controls.Add(this.resultPanel);
            this.Controls.Add(this.informationPanel);
            this.Controls.Add(this.menuMenuStrip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuMenuStrip;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CHARMS";
            this.Text = "CHARMS";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CHARMS_FormClosing);
            this.Load += new System.EventHandler(this.CHARMS_Load);
            this.menuMenuStrip.ResumeLayout(false);
            this.menuMenuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem displayFlightsListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewFlightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectFlightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchByPassengerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem displayPassengerManifestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editFlightInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewPassengerToManifestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem runPassengerSecurityCheckToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToCHARMSToolStripMenuItem;
        private System.Windows.Forms.Panel informationPanel;
        private System.Windows.Forms.Panel resultPanel;
        private System.Windows.Forms.ToolStripMenuItem displayFlightInformationToolStripMenuItem;

    }
}

