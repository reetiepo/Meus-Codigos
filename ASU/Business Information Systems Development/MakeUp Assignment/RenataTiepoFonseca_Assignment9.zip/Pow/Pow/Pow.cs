﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pow
{
    public partial class Pow : Form
    {
        // Assignment 9, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        // random variable to randomize the target speed
        private Random r;

        private int targetSpeed;

        private int totalScore;

        private int secondsLeft;

        // a sound variable to play the game sound
        private SoundPlayer soundPlayer;

        public Pow()
        {
            InitializeComponent();
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            // randomize a speed for the target
            r = new Random();
            targetSpeed = r.Next(4, 15);

            // setting the interval for each timer in milliseconds
            targetTimer.Interval = 20;
            gameTimer.Interval = 1000;
            bulletTimer.Interval = 10;

            targetPictureBox.Left = 0;
            bulletPictureBox.Left = 416;
            totalScore = 0;
            powPrefixLabel.Text = totalScore.ToString();

            // setting the game's element to visible
            statusLabel.Visible = targetPictureBox.Visible = bulletPictureBox.Visible = 
                powSulfixLabel.Visible = powPrefixLabel.Visible = fireButton.Visible = true;
            fireButton.Enabled = true;
            
            // starting the counter to the game time
            secondsLeft = 60;
            statusLabel.Text = secondsLeft.ToString();
            targetTimer.Start();
            gameTimer.Start();
        }

        private void targetTimer_Tick(object sender, EventArgs e)
        {
            // making the target move by the target speed
            targetPictureBox.Left += targetSpeed;

            // if the target gets to the end of the window restart its position to start again
            if (targetPictureBox.Left >= this.Width)
            {
                targetPictureBox.Location = new Point(0, 34);
                targetSpeed = r.Next(4, 15);
            }
        }

        private void gameTimer_Tick(object sender, EventArgs e)
        {
            // decrease the counter of the game time
            secondsLeft--;
            if (secondsLeft > 0)
            {
                statusLabel.Text = secondsLeft.ToString();
            }
            else // if the counter gets to 0 the game is over
            {
                gameTimer.Stop();
                bulletTimer.Stop();
                targetTimer.Stop();
                fireButton.Enabled = false;
                statusLabel.Text = "Game over";
            }
        }

        private void fireButton_Click(object sender, EventArgs e)
        {
            // starts the timer to the bullet when the fire button is clicked
            bulletPictureBox.Visible = true;
            bulletTimer.Start();
        }

        private void bulletTimer_Tick(object sender, EventArgs e)
        {
            // making the bullet move
            bulletPictureBox.Top -= 7;

            // if the bullet collided with the target increase the points and shows the pow animation
            if (Collided())
            {
                totalScore++;
                powPrefixLabel.Text = totalScore.ToString();
                bulletTimer.Stop();
                targetTimer.Stop();
                targetPictureBox.ImageLocation = "pow.png";
                targetPictureBox.Height = targetPictureBox.Width = 0;
                bulletPictureBox.Visible = false;
                powTimer.Start();
            }
            // if the bullet gets to the end of the window restart its position to start again
            if (bulletPictureBox.Top <= 0)
            {
                bulletTimer.Stop();
                bulletPictureBox.Visible = true;
                bulletPictureBox.Top = 250;
            }
        }

        // verifies if the bullet collided with the target
        private bool Collided()
        {
            if ((bulletPictureBox.Left >= targetPictureBox.Left &&
                bulletPictureBox.Left <= targetPictureBox.Right) &&
                (bulletPictureBox.Top <= targetPictureBox.Bottom &&
                bulletPictureBox.Top >= targetPictureBox.Top))
            {
                return true;
            }
            else if ((bulletPictureBox.Right >= targetPictureBox.Left &&
                bulletPictureBox.Right <= targetPictureBox.Right) &&
                (bulletPictureBox.Top <= targetPictureBox.Bottom &&
                bulletPictureBox.Top >= targetPictureBox.Top))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void powTimer_Tick(object sender, EventArgs e)
        {
            // makes the pow image grows
            targetPictureBox.Height++;
            targetPictureBox.Width++;

            // stops the pow animation and let the game continue
            if (targetPictureBox.Width == 25)
            {
                powTimer.Stop();
                bulletPictureBox.Top = 250;
                bulletPictureBox.Visible = true;
                targetPictureBox.Height = targetPictureBox.Width = 40;
                targetPictureBox.Location = new Point(0, 34);
                targetPictureBox.ImageLocation = "ship.png";
                targetSpeed = r.Next(4, 15);
                targetTimer.Start();
            }
        }

        private void Pow_Load(object sender, EventArgs e)
        {
            // sets the music to the game
            soundPlayer = new SoundPlayer("s2.wav");
            soundPlayer.Load();
            soundPlayer.PlayLooping();

            // initiate the game with all controls invisible except the new game button
            targetPictureBox.Visible = bulletPictureBox.Visible = fireButton.Visible = 
                powSulfixLabel.Visible = powPrefixLabel.Visible = statusLabel.Visible = false;
        }
    }
}
