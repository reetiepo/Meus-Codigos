﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FruitGarden
{
    class Banana : Fruit
    {
        // Assignment 5, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        public double Lenght { get; set; }

        public Banana(double lenght)
        {
            Lenght = lenght;
        }
    }
}
