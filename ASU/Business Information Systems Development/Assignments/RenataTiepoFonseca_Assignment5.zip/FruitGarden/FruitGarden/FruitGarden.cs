﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FruitGarden
{
    class FruitGarden
    {
        // Assignment 5, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        private void MakeFruitBasket()
        {
            FruitBasket basket1 = new FruitBasket();
            FruitBasket basket2 = new FruitBasket();

            basket1.BasketName = "Weekend";
            basket2.BasketName = "Weekday";

            basket1.MakeFruits();
            basket1.EatFruits();

            basket2.MakeFruits();
            basket2.EatFruits();
        }

        static void Main(string[] args)
        {
            FruitGarden myFruitGarden = new FruitGarden();

            myFruitGarden.MakeFruitBasket();

            Console.ReadLine();
        }
    }
}
