﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FruitGarden
{
    class FruitBasket
    {
        // Assignment 5, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        private Apple apple;
        
        private Banana banana;

        public string BasketName { get; set; }

        public void MakeFruits()
        {
            apple = new Apple(1.5);
            banana = new Banana(3.5);

            apple.PeelThickness = 1;
            banana.PeelThickness = 4;
        }

        public void EatFruits()
        {
            double amountToEat;

            Console.WriteLine("{0,40}***\n", "***" + BasketName.ToUpper());

            Console.WriteLine("You have an apple and a banana in your {0} basket.\n", BasketName);

            Console.Write("What percentage of the apple would you like to eat? ");
            amountToEat = Convert.ToDouble(Console.ReadLine());
            apple.Eat(amountToEat);

            Console.Write("What percentage of the banana would you like to eat? ");
            amountToEat = Convert.ToDouble(Console.ReadLine());
            banana.Eat(amountToEat);

            Console.WriteLine("\nYou have {0}% of your apple and {1}% of your banana left in your {2} basket.\n", apple.PercentLeft, banana.PercentLeft, BasketName);
        }
    }
}
