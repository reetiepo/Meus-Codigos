﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FruitGarden
{
    class Apple : Fruit
    {
        // Assignment 5, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        public double Radius { get; set; }

        public Apple(double radius) 
        {
            Radius = radius;
        }
    }
}
