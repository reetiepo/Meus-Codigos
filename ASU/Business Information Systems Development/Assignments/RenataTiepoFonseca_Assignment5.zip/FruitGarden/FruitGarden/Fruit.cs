﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FruitGarden
{
    class Fruit
    {
        // Assignment 5, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        private double fruitPercentLeft;

        public double PercentLeft { get { return fruitPercentLeft; } }

        public int PeelThickness { get; set; }

        public Fruit() 
        {
            fruitPercentLeft = 100.0;
        }

        public void Eat(double eatenAmount) 
        {
            fruitPercentLeft -= eatenAmount;
        }
    }
}
