﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Methods
    {
        //Assignment 2, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        static void Main(string[] args)
        {
            int additionResult = 0;
            int number1 = 7;
            int number2 = 6;
            int quotient = 0;
            int remainder = 0;
            int product = 0;
            bool numberIsEven = false;
            double divisionResult = 0.0;

            Console.WriteLine("*** Using overloaded methods ***");

            //Add
            additionResult = Add(5, 2);
            Console.WriteLine("The sum of 5 and 2 is {0}", additionResult);
            Console.WriteLine("The sum of 5 and 5 and 2.5 is {0:f2}\n", Add(5, 5, 2.5));

            //Concatenate
            Console.WriteLine("4 and 2 concatenated is {0}.", Concatenate(4, 2));
            Console.WriteLine("\"4\" and \"2\" concatenated is {0}.\n\n", Concatenate("4", "2"));

            Console.WriteLine("*** Processing boolean return values ***");
            //IsEven
            Console.WriteLine("Testing if the number 4 is even or odd....");
            numberIsEven = IsEven(4);
            Console.Write("4 is ");
            if (numberIsEven)
                Console.WriteLine("even.\n");
            else
                Console.WriteLine("odd.\n");
            Console.WriteLine("Testing if the number 5 is even or odd....");
            numberIsEven = IsEven(5);
            Console.Write("5 is ");
            if (numberIsEven)
                Console.WriteLine("even.\n\n");
            else
                Console.WriteLine("odd.\n\n");

            Console.WriteLine("*** Passing parameters by-value vs. by-reference ***");
            //Divide
            divisionResult = Divide(7, 6);
            Console.WriteLine("7/6 is {0:f4}", divisionResult);
            divisionResult = Divide(number1, number2, ref quotient, ref remainder);
            Console.WriteLine("7/6: Quotient is {0}. Remainder is {1}.\n\n\n", quotient, remainder);

            Console.WriteLine("*** Using required and optional arguments ***");
            //Multiply
            product = Multiply(5);
            Console.WriteLine("Calling Multiply with 1 argument: 5");
            Console.WriteLine("Product is {0}\n", product);
            product = Multiply(5, 2);
            Console.WriteLine("Calling Multiply with 2 arguments: 5 and 2");
            Console.WriteLine("Product is {0}\n", product);
            product = Multiply(5, 2, 3);
            Console.WriteLine("Calling Multiply with 1 argument: 5, 2, and 3");
            Console.WriteLine("Product is {0}\n", product);

            Console.ReadLine();
        }

        private static int Add(int number1, int number2)
        {
            return number1 + number2;
        }

        private static double Add(int number1, int number2, double number3)
        {
            return number1 + number2 + number3;
        }

        private static string Concatenate(string string1, string string2)
        {
            return (string1 + string2);
        }

        private static string Concatenate(int number1, int number2)
        {
            string outputText = "";
            outputText = Concatenate(number1.ToString(), number2.ToString());
            return outputText;
        }

        private static bool IsEven(int number)
        {
            if (number % 2 == 0)
                return true;
            else
                return false;
        }

        private static double Divide(int number1, int number2)
        {
            double quotient = 0.0;
            quotient = ((double)number1) / number2;
            return quotient;
        }

        private static int Divide(int number1, int number2, ref int quotient, ref int remainder)
        {
            quotient = number1 / number1;
            remainder = number1 % number2;
            return 0;
        }

        private static int Multiply(int number1, int number2 = 1, int number3 = 1)
        {
            int product = 0;
            product = number1 * number2 * number3;
            return product;
        }
    }
}
