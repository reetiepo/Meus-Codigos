﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheNewLibrary
{
    class Book
    {
        // Assignment 6, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        private string BookName { get; set; }

        private int publicationYear;

        private int PublicationYear
        {
            get
            {
                return publicationYear;
            }

            set
            {
                // Verifies if the publication year is valid (between 1100 and 2014)
                // if not, set the year as the default value 1900
                if (value >= 1100 & value <= 2014)
                    publicationYear = value;
                else
                    publicationYear = 1900;
            }
        }

        public Book(string name, int year)
        {
            // Defines the attributes for a new book
            BookName = name;
            PublicationYear = year;
        }

        public string GetBookName()
        {
            return BookName;
        }

        public int GetPublicationYear()
        {
            return PublicationYear;
        }

        public int GetBookNameLenght()
        {
            return BookName.Length;
        }
    }
}
