﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheNewLibrary
{
    class LibrarySystem
    {
        // Assignment 6, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        private static Book[] books;

        // Clear the screen and write the System's name
        private static void DisplayMenu()
        {
            Console.Clear();

            Console.WriteLine("{0,50}", "New Library System\n\n");
        }

        // Reads the book title and year and add the new book to the book's array 
        private static void AddBook(int index)
        {
            int year;
            string name;

            Console.Write("\nEnter Book Title: ");
            name = Console.ReadLine();
            Console.Write("Enter Book Year: ");
            year = Convert.ToInt32(Console.ReadLine());

            books[index] = new Book(name, year);
            Console.Write("Title '{0}' added to the library.\n", name);
        }

        // Display the array of book as a list
        private static void DisplayBookList()
        {
            int spaces = 0;

            Console.WriteLine("{0,20} {1,40}\n", "Title", "Year");
            for (int i = 0; i < books.Length; i++)
            {
                spaces = 61 - books[i].GetBookNameLenght();
                Console.WriteLine("{0}{1," + spaces + "}", books[i].GetBookName(), books[i].GetPublicationYear());
            }

            Console.ReadLine();
        }

        // Ask the number of books that will be added to the list and create the array of books
        private static void LoadLibrarySystem()
        {
            int newBooks = 0;

            Console.Write("How many new books do you want to add to the Library? ");
            newBooks = Convert.ToInt32(Console.ReadLine());

            books = new Book[newBooks];

            for (int i = 0; i < newBooks; i++)
            {
                AddBook(i);
            }

            Console.ReadLine();
        }

        static void Main(string[] args)
        {
            DisplayMenu();
            LoadLibrarySystem();
            DisplayMenu();
            DisplayBookList();
        }
    }
}
