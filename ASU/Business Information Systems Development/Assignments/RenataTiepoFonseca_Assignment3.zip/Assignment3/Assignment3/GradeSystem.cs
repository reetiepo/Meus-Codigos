﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class GradeSystem
    {
        // Assignment  3, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        // This method populate the array of students' names
        static void PopulateNameArray(string[] names)
        {
            Console.WriteLine("****************************\nEnter the name of {0} students\n****************************\n", names.Length);

            // Loop through the array of names
            for (int i = 0; i < names.Length; i++)
            {
                // Read the name of the student for every field of the array
                names[i] = Console.ReadLine();
            }
        }

        // This method populate the array of students' score according to the array of students' name
        static void PopulateScoreArray(string[] names, int[] scores)
        {
            Console.WriteLine("****************************\nEnter scores. One score per line.\n****************************\n");

            // Loop through the array of names
            for (int i = 0; i < names.Length; i++)
            {
                Console.Write("Enter score for {0}: ", names[i]);
                // Read the score for the specific student according to the name position
                scores[i] = Convert.ToInt32(Console.ReadLine());
            }
        }

        // This method find the position of the student score according to the student name
        static int FindStudentPosition(string name, string[] stringArray)
        {
            // Variable to allocate the position of the student, if found
            int studentLocation = -1;

            // Loop through the array of names
            for (int i = 0; i < stringArray.Length; i++)
            {
                // Compare if the name of this position is equal to the searched name
                if (stringArray[i] == name)
                {
                    // Saves the position of the student
                    studentLocation = i;
                    // Finish the search
                    break;
                }
            }

            return studentLocation;
        }

        // This method centralized the string on the screen
        static void WriteCenteredLine(string str)
        {
            // Get the width of the screen plus the size of the string
            int x = Console.WindowWidth + str.Length;
            // Show the string in the middle of the calculated width of the screen
            Console.WriteLine("{0," + x/2 + "}", str);
        }

        static void Main(string[] args)
        {
            // Arrays to allocate the name and score of the student
            string[] nameArray = new string[5];
            int[] scoreArray = new int[5];
            // String to get the name of the searched student
            string name = "";
            // Variable to allocate the position of the student
            int studentPosition;

            WriteCenteredLine("Student Grade Systems\n");
            Console.WriteLine("This program will store students grades and look them up for you.\n");

            // Populate the array of names and scores
            PopulateNameArray(nameArray);
            Console.WriteLine("");
            PopulateScoreArray(nameArray, scoreArray);

            // Clear the screen
            Console.Clear();

            Console.Write("Enter name of student whose score you want to find: ");
            name = Console.ReadLine();

            // Find the position of the searched student
            studentPosition = FindStudentPosition(name, nameArray);

            // If founded, show the score of the student, if not, inform that was not found.
            if (studentPosition == -1)
                Console.WriteLine("\nI'm sorry. There is no student by that name.");
            else
                Console.WriteLine("\n{0}'s score is {1}", nameArray[studentPosition], scoreArray[studentPosition]);

            Console.ReadKey();
        }
    }
}
