﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AverageCalculator
{
    public partial class AverageCalculator : Form
    {
        // Assignment 7, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        private TextBox[] scoreTextBoxArray;

        public AverageCalculator()
        {
            InitializeComponent();
        }

        private void AverageCalculator_Load(object sender, EventArgs e)
        {
            calculateButton.Visible = false;
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            int numberOfTextBoxes = Convert.ToInt32(numberofScoresTextBox.Text);

            this.Height = 500;
            calculateButton.Visible = true;
            okButton.Enabled = false;
            CreateTextBoxes(numberOfTextBoxes);
        }

        private void CreateTextBoxes(int number)
        {
            scoreTextBoxArray = new TextBox[number];
            int verticalTopPosition = 150;

            for (int i = 0; i < number; i++)
            {
                scoreTextBoxArray[i] = new TextBox();
                scoreTextBoxArray[i].Left = 20;
                scoreTextBoxArray[i].Top = verticalTopPosition;
                verticalTopPosition += 50;
                this.Controls.Add(scoreTextBoxArray[i]);
            }

        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double total = 0.0;
            double average = 0.0;

            for (int i = 0; i < scoreTextBoxArray.Length; i++)
            {
                total += Convert.ToInt32(scoreTextBoxArray[i].Text);
            }

            average = Convert.ToDouble(total / scoreTextBoxArray.Length);

            scoresLabel.Text = "Average is " + Convert.ToString(average);
        }
    }
}
