﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Loops
    {
        //Assignment 1, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        static void Main(string[] args)
        {
            int i, j , k, read, result;

            #region CIS 345 Assignment 1, Part 1 – Odd Numbers

            Console.WriteLine("CIS 345 Assignment 1, Part 1 – Odd Numbers");

            i = 1;

            while (i <= 20)
            {
                Console.Write(i + " ");
                i += 2;
            }

            #endregion

            Console.WriteLine("\n\n");

            #region CIS 345 Assignment 1, Part 2 – Even Numbers

            Console.WriteLine("CIS 345 Assignment 1, Part 2 – Even Numbers");

            for (i = 1; i <= 20; i++)
            {
                if (i % 2 == 0)
                    Console.Write(i + " ");
            }

            #endregion

            Console.WriteLine("\n\n");

            #region CIS 345 Assignment 1, Part 3 – Factorial

            Console.WriteLine("CIS 345 Assignment 1, Part 3 – Factorial");
            Console.Write("Enter a number for the factorial: ");
            read = Convert.ToInt32(Console.ReadLine());
            result = 1;

            for (i = read; i > 0; i--)
            {
                result *= i;
            }

            Console.WriteLine("The factorial is " + result);

            #endregion

            Console.WriteLine("\n\n");

            #region CIS 345 Assignment 1, Part 4 - Triangles

            Console.WriteLine("CIS 345 Assignment 1, Part 4 - Triangles");

            for (i = 10; i >= 1; i--)
            {
                for (j = i; j >= 1; j--)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }

            Console.WriteLine();

            for (i = 1; i <= 10; i++)
            {
                for (j = 10; j >= i - 1; j--)
                {
                    Console.Write(" ");
                }
                for (k = 1; k <= i; k++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }

            #endregion

            Console.WriteLine("\n\n");

            Console.WriteLine("Pess any key for next page...");
            Console.ReadKey();
            Console.Clear();

            #region CIS 345 Assignment 1, Part 5 – Multiplication Table

            int[] table = { 10, 20, 30, 40, 50 };

            Console.WriteLine("CIS 345 Assignment 1, Part 5 – Multiplication Table");

            for (i = 5; i <= 10; i++)
            {
                for (j = 0; j < table.Length; j++)
                {
                    Console.WriteLine("{0,2} * {1}  = {2,5}", i, table[j], i * table[j]);
                }
                Console.WriteLine();
            }

            #endregion

            Console.WriteLine("Pess any key to Exit...");
            Console.ReadKey();
        }
    }
}
