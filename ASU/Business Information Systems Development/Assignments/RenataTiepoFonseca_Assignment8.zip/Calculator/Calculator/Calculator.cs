﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Calculator : Form
    {
        // Assignment 8, Renata Tiepo Fonseca, CIS 345, Monday/Wednesday 3:00 PM

        private string number1 = "0";

        // indicate the math operation
        private string math = "";

        public Calculator()
        {
            InitializeComponent();
        }

        private void zeroButton_Click(object sender, EventArgs e)
        {
            if (textLabel.Text == "Infinity")
                textLabel.Text = "";

            textLabel.Text = textLabel.Text + "0";
        }

        private void oneButton_Click(object sender, EventArgs e)
        {
            if (textLabel.Text == "Infinity")
                textLabel.Text = "";

            textLabel.Text = textLabel.Text + "1";
        }

        private void twoButton_Click(object sender, EventArgs e)
        {
            if (textLabel.Text == "Infinity")
                textLabel.Text = "";

            textLabel.Text = textLabel.Text + "2";
        }

        private void threeButton_Click(object sender, EventArgs e)
        {
            if (textLabel.Text == "Infinity")
                textLabel.Text = "";

            textLabel.Text = textLabel.Text + "3";
        }

        private void fourButton_Click(object sender, EventArgs e)
        {
            if (textLabel.Text == "Infinity")
                textLabel.Text = "";

            textLabel.Text = textLabel.Text + "4";
        }

        private void fiveButton_Click(object sender, EventArgs e)
        {
            if (textLabel.Text == "Infinity")
                textLabel.Text = "";

            textLabel.Text = textLabel.Text + "5";
        }

        private void sixButton_Click(object sender, EventArgs e)
        {
            if (textLabel.Text == "Infinity")
                textLabel.Text = "";

            textLabel.Text = textLabel.Text + "6";
        }

        private void sevenButton_Click(object sender, EventArgs e)
        {
            if (textLabel.Text == "Infinity")
                textLabel.Text = "";

            textLabel.Text = textLabel.Text + "7";
        }

        private void eightButton_Click(object sender, EventArgs e)
        {
            if (textLabel.Text == "Infinity")
                textLabel.Text = "";

            textLabel.Text = textLabel.Text + "8";
        }

        private void nineButton_Click(object sender, EventArgs e)
        {
            if (textLabel.Text == "Infinity")
                textLabel.Text = "";

            textLabel.Text = textLabel.Text + "9";
        }

        private void dotButton_Click(object sender, EventArgs e)
        {
            if (textLabel.Text == "Infinity" || textLabel.Text == "")
                textLabel.Text = "0";

            textLabel.Text = textLabel.Text + ".";
        }

        private void ACButton_Click(object sender, EventArgs e)
        {
            textLabel.Text = "";
            number1 = "0";
            math = "";
        }

        private void multiplyButton_Click(object sender, EventArgs e)
        {
            if (textLabel.Text == "Infinity")
                textLabel.Text = "";

            if (textLabel.Text != "")
            {
                math = "*";
                number1 = textLabel.Text;
                textLabel.Text = "";
            }
        }

        private void divideButton_Click(object sender, EventArgs e)
        {
            if (textLabel.Text == "Infinity")
                textLabel.Text = "";

            if (textLabel.Text != "")
            {
                math = "/";
                number1 = textLabel.Text;
                textLabel.Text = "";
            }
        }

        private void subtractButton_Click(object sender, EventArgs e)
        {
            if (textLabel.Text == "Infinity")
                textLabel.Text = "";

            if (textLabel.Text != "")
            {
                math = "-";
                number1 = textLabel.Text;
                textLabel.Text = "";
            }
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            if (textLabel.Text == "Infinity")
                textLabel.Text = "";

            if (textLabel.Text != "")
            {
                math = "+";
                number1 = textLabel.Text;
                textLabel.Text = "";
            }
        }

        private void equalButton_Click(object sender, EventArgs e)
        {
            if (textLabel.Text == "Infinity")
                textLabel.Text = "";

            string result = "";
            double num1 = Convert.ToDouble(number1);
            double num2 = 0;

            if (textLabel.Text != "")
                num2 = Convert.ToDouble(textLabel.Text);

            switch (math)
            {
                case "+":
                    result = (num1 + num2).ToString();
                    break;
                case "-":
                    result = (num1 - num2).ToString();
                    break;
                case "/":
                    if (num2 == 0)
                        result = "Infinity";
                    else
                        result = (num1 / num2).ToString();
                    break;
                case "*":
                    result = (num1 * num2).ToString();
                    break;            
                default:
                    result = "0";
                    break;
            }

            textLabel.Text = result.ToString();
        }
    }
}
